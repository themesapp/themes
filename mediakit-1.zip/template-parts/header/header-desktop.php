<?php 
if (is_active_sidebar('parallax_desktop')) : ?>
	<div class="adx-parallax">
	<div class="parallax-box">
	<div class="parallax-wrap">
		<?php dynamic_sidebar('parallax_desktop'); ?>
	</div>
	</div>
	</div>
<?php
endif;
?>
<div class="box-header">
<header class="header-app">
  <div class="container">
    <div class="row">
      <div class="col-5">
        <div class="header-app-box box-left">
          <div class="header-app-item">
            <div class="social-app-box">
            <?php if ( "" != (get_theme_mod( 'tombolfollowfacebook' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowfacebook' ); ?>" target="_blank" class="social-app-link facebook">
                  <span class="icon icon-facebook"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowtwitter' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowtwitter' ); ?>" target="_blank" class="social-app-link twitter">
                  <span class="icon icon-twitter"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowinstagram' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowinstagram' ); ?>" target="_blank" class="social-app-link instagram">
                  <span class="icon icon-instagram"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowyoutube' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowyoutube' ); ?>" target="_blank" class="social-app-link youtube">
                  <span class="icon icon-youtube"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowtelegram' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowtelegram' ); ?>" target="_blank" class="social-app-link telegram">
                  <span class="icon-telegram"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowdiscord' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowdiscord' ); ?>" target="_blank" class="social-app-link discord">
                  <span class="icon-discord"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowgnews' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowgnews' ); ?>" target="_blank" class="social-app-link gnews">
                  <span class="icon-gnews"></span>
                </a>
              </div>
            <?php endif; ?>
            </div>
          </div>
          <?php if ( true == get_theme_mod( 'date', true )) : ?>
          <div class="header-app-item">
            <div class="header-date">
              <?php $date = date_i18n( get_option( 'date_format' ), strtotime( get_the_date( 'r' ) ) ); echo $date ;?>              
              </div>
          </div>
         <?php endif; ?>
        </div>
      </div> 
      <div class="col-2">
          <div class="app-logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
      </div>
      <div class="col-5">
        <div class="header-app-box box-right">
          <?php if ( true == get_theme_mod( 'mode', true )) : ?>
          <div class="header-app-item">
              <button class="mode" aria-label="mode">
                <i class="dark"></i>
              </button>
          </div>
          <?php endif; ?>
          <?php if (has_nav_menu('network_menu' )) : ?>
          <div class="header-app-item netbox">
              <button class="btn-network" aria-label="network">
                <i class="icons icons-bookmark"></i>
                <span><?php echo wp_get_nav_menu_name('network_menu') ?></span>
              </button>
              <div class="network-box">
              <?php network_menu(); ?>
              </div>
          </div>
          <?php endif; ?>
          <div class="header-app-item searchbox">
              <button class="btn-search" aria-label="search">
                <i class="icon icons-search"></i>
              </button>
              <form class="form-search" method="get" action="<?php echo home_url('/'); ?>">
                  <input class="input-search" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
                  <input type="hidden" name="post_type" value="post" />
              </form>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</header>
<nav class="app-nav">
  <div class="container">
    <div class="nav-wrap">
      <div class="nav-home">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="Home">
          <span class="icon icons-home"></span>
        </a>
      </div>
      <?php
      if ( has_nav_menu( 'menu_utama' ) ) : 
        menu_utama();
      endif;
      ?>
    </div>
  </div>
</nav>
</div>

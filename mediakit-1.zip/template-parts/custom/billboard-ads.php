<?php
if (is_active_sidebar('billboard_area')) :?>
<div class="container">
<div class="billboard">
<?php dynamic_sidebar('billboard_area');?>
</div>
</div>
<?php endif;?>
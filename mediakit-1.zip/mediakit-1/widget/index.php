<?php 
require 'sliderheadline.php';
require 'sliderinline.php';
require 'slidervideo.php';
require 'slideroutline.php';
require 'slideroutlinefeed.php';
require 'terkiniinline.php';
require 'terkinioutline.php';
require 'related.php';
require 'list.php';
require 'listfeed.php';
require 'popularpos.php';
require 'populartag.php';
require 'topikoutline.php';
require 'listnetworkbody.php';
require 'feednetworkbody.php';
require 'contact.php';

function listberandaViewDesktop($title,$start,$jml){
  global $post;
    $args = array(
      'post_type' => 'post',
      'post_status' => 'publish',
      'offset' => $start,
      'posts_per_page'=> $jml
    );

	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
		?>
     <div class="widget list">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
		<?php
		$num = 1;
		while ( $my_query->have_posts() ) {
			$my_query->the_post();
			?>
        <div class="list-item">
          <div class="list-hastag">#</div>
          <div class="list-content">
          	<div class="list-date"><?php echo timeago(); ?></div>
              <h2 class="list-title">
              	<a href="<?php echo get_permalink(); ?>" class="list-link media-link" target="_blank">
              		<?php echo get_the_title(); ?>
              	</a>
              </h2>
          </div>
        </div>
			<?php
			}
			wp_reset_postdata();
			?>
	     	</div>
	     </div>
		<?php 
	endif;
}
function listberandaViewMobile($title,$start,$jml){
  global $post;
    $args = array(
      'post_type' => 'post',
      'post_status' => 'publish',
      'offset' => $start,
      'posts_per_page'=> $jml
    );

	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
		?>
     <div class="widget list">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
		<?php
		$num = 1;
		while ( $my_query->have_posts() ) {
			$my_query->the_post();
			?>
        <div class="list-item">
          <div class="list-hastag">#</div>
          <div class="list-content">
          	<div class="list-date"><?php echo timeago(); ?></div>
              <h2 class="list-title">
              	<a href="<?php echo get_permalink(); ?>" class="list-link media-link" target="_blank">
              		<?php echo get_the_title(); ?>
              	</a>
              </h2>
          </div>
        </div>
			<?php
			}
			wp_reset_postdata();
			?>
	     	</div>
	     </div>
		<?php 
	endif;
}
class listberandaWidget extends WP_Widget {

	public function __construct() {
		$idwidget = 'listberanda';
		$namewidget = '📌 List Artikel Body';
		$descwidget = 'Daftar / List post terbaru berdasarkan kategori / tag di body.';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				listberandaViewMobile($instance['title'], $instance['start'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				listberandaViewMobile($instance['title'], $instance['start'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				listberandaViewDesktop($instance['title'], $instance['start'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['start'] ) ) {
			$instance['start'] = sanitize_text_field( $new_instance['start'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}
	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'start' => '1',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Widget</h3>
		  <p>
			<label for="<?php echo $this->get_field_id( 'start' ); ?>">Dimulai pos ke:</label>
			<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'start' ); ?>" name="<?php echo $this->get_field_name( 'start' ); ?>" min="1" value="<?php echo $instance['start']; ?>" required/>
		  </p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo 'Jumlah pos di desktop:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" min="1" max="10" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo 'Jumlah pos di mobile:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" min="1" max="10" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function listberandaWidgetload() {
	register_widget( 'listberandaWidget' );
}
add_action( 'widgets_init', 'listberandaWidgetload' );


function listindexViewDesktop($title,$start,$url,$jml){
  global $post;
    $args = array(
      'post_type' => 'post',
      'post_status' => 'publish',
      'offset' => $start,
      'posts_per_page'=> $jml
    );

	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
		?>
     <div class="widget list">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
		<?php
		$num = 1;
		while ( $my_query->have_posts() ) {
			$my_query->the_post();
			?>
        <div class="list-item">
          <div class="list-hastag">#</div>
          <div class="list-content">
          	<div class="list-date"><?php echo timeago(); ?></div>
              <h2 class="list-title">
              	<a href="<?php echo get_permalink(); ?>" class="list-link media-link" target="_blank">
              		<?php echo get_the_title(); ?>
              	</a>
              </h2>
          </div>
        </div>
			<?php
			}
			wp_reset_postdata();
			?>
          </div>
		      <?php if(!empty($url)): ?>
	          <div class="widget-footer">
	            <a href="<?php echo esc_url($url); ?>" class="btn-index">Lihat Semua</a>
	          </div>
	      	<?php endif; ?>
        </div>
		<?php 
	endif;
}
function listindexViewMobile($title,$start,$url,$jml){
  global $post;
    $args = array(
      'post_type' => 'post',
      'post_status' => 'publish',
      'offset' => $start,
      'posts_per_page'=> $jml
    );

	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ):
		?>
     <div class="widget list">
        <?php if(!empty($title)): ?>
	     	<div class="widget-header">
	     		<h3 class="title"><?php echo $title; ?></h3>
	     	</div>
	      <?php endif; ?>
	     	<div class="widget-content">
		<?php
		$num = 1;
		while ( $my_query->have_posts() ) {
			$my_query->the_post();
			?>
        <div class="list-item">
          <div class="list-hastag">#</div>
          <div class="list-content">
          	<div class="list-date"><?php echo timeago(); ?></div>
              <h2 class="list-title">
              	<a href="<?php echo get_permalink(); ?>" class="list-link media-link" target="_blank">
              		<?php echo get_the_title(); ?>
              	</a>
              </h2>
          </div>
        </div>
			<?php
			}
			wp_reset_postdata();
			?>
          </div>
		      <?php if(!empty($url)): ?>
	          <div class="widget-footer">
	            <a href="<?php echo esc_url($url); ?>" class="btn-index">Lihat Semua</a>
	          </div>
	      	<?php endif; ?>
        </div>
		<?php 
	endif;
}
class listindexWidget extends WP_Widget {

	public function __construct() {
		$idwidget = 'listindex';
		$namewidget = '📌 List Artikel Index';
		$descwidget = 'Daftar / List post terbaru berdasarkan kategori / tag di body.';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				listindexViewMobile($instance['title'], $instance['start'],$instance['url'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				listindexViewMobile($instance['title'], $instance['start'],$instance['url'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				listindexViewDesktop($instance['title'], $instance['start'],$instance['url'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['start'] ) ) {
			$instance['start'] = sanitize_text_field( $new_instance['start'] );
		}
		if ( ! empty( $new_instance['url'] ) ) {
			$instance['url'] = sanitize_text_field( $new_instance['url'] );
		}
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}
	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'start' => '1',
			'url' => '',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Widget</h3>
		  <p>
			<label for="<?php echo $this->get_field_id( 'start' ); ?>">Dimulai pos ke:</label>
			<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'start' ); ?>" name="<?php echo $this->get_field_name( 'start' ); ?>" min="1" value="<?php echo $instance['start']; ?>" required/>
		  </p>
			<p>
				<label for="<?php echo $this->get_field_id( 'url' ); ?>">URL index:</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'url' ); ?>" name="<?php echo $this->get_field_name( 'url' ); ?>" value="<?php echo $instance['url']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo 'Jumlah pos di desktop:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" min="1" max="10" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo 'Jumlah pos di mobile:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" min="1" max="10" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function listindexWidgetload() {
	register_widget( 'listindexWidget' );
}
add_action( 'widgets_init', 'listindexWidgetload' );
?>
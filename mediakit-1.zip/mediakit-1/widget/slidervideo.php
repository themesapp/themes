<?php
function covtime($youtube_time){
    if($youtube_time) {
        $start = new DateTime('@0'); // Unix epoch
        $start->add(new DateInterval($youtube_time));
        $youtube_time = $start->format('H:i:s');
    } 
    return $youtube_time;
}   
function get_youtube($dataapi, $dataurl, $dateget){
	parse_str( parse_url( $dataurl, PHP_URL_QUERY ), $my_array_of_vars );
	$youtube = "https://www.googleapis.com/youtube/v3/videos?part=contentDetails&part=snippet&id=". $my_array_of_vars['v'] ."&key=" . $dataapi;
	$curl = curl_init($youtube);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$return = curl_exec($curl);
	curl_close($curl);
	$decoded = json_decode($return, true);
	if($dateget == "title"){
    foreach ($decoded['items'] as $items) {
         $code = $items['snippet']['title'];
         return $code;
    }
    }
	if($dateget == "imagedefault"){
    foreach ($decoded['items'] as $items) {
         $code = $items['snippet']['thumbnails']['default']['url'];
         return $code;
    }
    }
	if($dateget == "imagemedium"){
    foreach ($decoded['items'] as $items) {
         $code = $items['snippet']['thumbnails']['medium']['url'];
         return $code;
    }
    }
	if($dateget == "imagehigh"){
    foreach ($decoded['items'] as $items) {
         $code = $items['snippet']['thumbnails']['high']['url'];
         return $code;
    }
    }
	if($dateget == "duration"){
    foreach ($decoded['items'] as $items) {
         $code = covtime($items['contentDetails']['duration']);
         return $code;
    }
    }
}
function slidervideoViewDesktop($api, $title, $embed_1, $embed_2, $embed_3, $embed_4, $embed_5, $embed_6, $embed_7, $embed_8, $embed_9, $embed_10){
	$arrayembed = array($embed_1, $embed_2, $embed_3, $embed_4, $embed_5, $embed_6, $embed_7, $embed_8, $embed_9, $embed_10);
	?>
	<?php if(!empty($api)): ?>
	<div class="slidervideo">
		<div class="slidervideo-row">
			<div class="slidervideo-big">
			<?php 
			foreach($arrayembed as $big) {
				$no = $numbig++; 
				if(!empty($big)):
				parse_str( parse_url( $big, PHP_URL_QUERY ), $my_array_of_vars );
				$idyt = $my_array_of_vars['v'];
				?>
				<figure class="wp-block-embed is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">
					<iframe title="Full Screen" width="500" height="281" src="https://www.youtube.com/embed/<?php echo $idyt; ?>?feature=oembed" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
					</div></figure>
				<?php
				break;
				endif;
			}
			?>
			</div>
			<div class="slidervideo-small">
			<?php 
			$num = 1;
			foreach($arrayembed as $embed) { 
			if(!empty($embed)):
			$no = $num++;
				if($no == 1):
					$class = "active";
				else:
					$class = "noactive";
				endif;
				parse_str( parse_url( $embed, PHP_URL_QUERY ), $my_array_of_vars );
				$idyt = $my_array_of_vars['v'];
				?>
				<div class="smallvideo-item <?php echo $class; ?>" data-url="https://www.youtube.com/embed/<?php echo $idyt; ?>?feature=oembed">
					<div class="smallvideo-img">
						<img src="<?php echo get_youtube($api, $embed, "imagedefault"); ?>" alt="<?php echo get_youtube($api, $embed, "title"); ?>"/>
					</div>
					<div class="smallvideo-text">
						<h3 class="smallvideo-title"><?php echo get_youtube($api, $embed, "title"); ?></h3>
						<div class="smallvide-duration"><?php echo get_youtube($api, $embed, "duration"); ?></div>					
					</div>
				</div>
			<?php endif; ?>
			<?php } ?>
			</div>
		</div>	
	</div>
	<?php
	endif;
}
function slidervideoViewMobile($api, $title, $embed_1, $embed_2, $embed_3, $embed_4, $embed_5, $embed_6, $embed_7, $embed_8, $embed_9, $embed_10){
	$arrayembed = array($embed_1, $embed_2, $embed_3, $embed_4, $embed_5, $embed_6, $embed_7, $embed_8, $embed_9, $embed_10);
	?>
	<?php if(!empty($api)): ?>
	<div class="slidervideo">
		<div class="slidervideo-row">
			<div class="slidervideo-big">
			<?php 
			foreach($arrayembed as $big) {
				$no = $numbig++; 
				if(!empty($big)):
				parse_str( parse_url( $big, PHP_URL_QUERY ), $my_array_of_vars );
				$idyt = $my_array_of_vars['v'];
				?>
				<figure class="wp-block-embed is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">
					<iframe title="Full Screen" width="500" height="281" src="https://www.youtube.com/embed/<?php echo $idyt; ?>?feature=oembed" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
					</div></figure>
				<?php
				break;
				endif;
			}
			?>
			</div>
			<div class="slidervideo-small">
			<?php 
			$num = 1;
			foreach($arrayembed as $embed) { 
			if(!empty($embed)):
			$no = $num++;
				if($no == 1):
					$class = "active";
				else:
					$class = "noactive";
				endif;
				parse_str( parse_url( $embed, PHP_URL_QUERY ), $my_array_of_vars );
				$idyt = $my_array_of_vars['v'];
				?>
				<div class="smallvideo-item <?php echo $class; ?>" data-url="https://www.youtube.com/embed/<?php echo $idyt; ?>?feature=oembed">
					<div class="smallvideo-img">
						<img src="<?php echo get_youtube($api, $embed, "imagedefault"); ?>" alt="<?php echo get_youtube($api, $embed, "title"); ?>"/>
					</div>
					<div class="smallvideo-text">
						<h3 class="smallvideo-title"><?php echo get_youtube($api, $embed, "title"); ?></h3>
						<div class="smallvide-duration"><?php echo get_youtube($api, $embed, "duration"); ?></div>					
					</div>
				</div>
			<?php endif; ?>
			<?php } ?>
			</div>
		</div>	
	</div>
	<?php
	endif;
}
class slidervideo extends WP_Widget {

	public function __construct() {
		$idwidget = 'slidervideo';
		$namewidget = '📌 Slider Video';
		$descwidget = 'Slider video menampilkan daftar video youtube berdasarkan url';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				slidervideoViewMobile(preg_replace('/\s+/', '', $instance['api']),$instance['title'], $instance['embed_1'], $instance['embed_2'], $instance['embed_3'], $instance['embed_4'], $instance['embed_5'], $instance['embed_6'], $instance['embed_7'], $instance['embed_8'], $instance['embed_9'], $instance['embed_10']);
			}elseif (wp_is_mobile()) {
				slidervideoViewMobile(preg_replace('/\s+/', '', $instance['api']),$instance['title'], $instance['embed_1'], $instance['embed_2'], $instance['embed_3'], $instance['embed_4'], $instance['embed_5'], $instance['embed_6'], $instance['embed_7'], $instance['embed_8'], $instance['embed_9'], $instance['embed_10']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				slidervideoViewDesktop(preg_replace('/\s+/', '', $instance['api']),$instance['title'], $instance['embed_1'], $instance['embed_2'], $instance['embed_3'], $instance['embed_4'], $instance['embed_5'], $instance['embed_6'], $instance['embed_7'], $instance['embed_8'], $instance['embed_9'], $instance['embed_10']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['api'] ) ) {
			$instance['api'] = sanitize_text_field( $new_instance['api'] );
		}
		if ( ! empty( $new_instance['embed_1'] ) ) {
			$instance['embed_1'] = sanitize_text_field( $new_instance['embed_1'] );
		}
		if ( ! empty( $new_instance['embed_2'] ) ) {
			$instance['embed_2'] = sanitize_text_field( $new_instance['embed_2'] );
		}
		if ( ! empty( $new_instance['embed_3'] ) ) {
			$instance['embed_3'] = sanitize_text_field( $new_instance['embed_3'] );
		}
		if ( ! empty( $new_instance['embed_4'] ) ) {
			$instance['embed_4'] = sanitize_text_field( $new_instance['embed_4'] );
		}
		if ( ! empty( $new_instance['embed_5'] ) ) {
			$instance['embed_5'] = sanitize_text_field( $new_instance['embed_5'] );
		}
		if ( ! empty( $new_instance['embed_6'] ) ) {
			$instance['embed_6'] = sanitize_text_field( $new_instance['embed_6'] );
		}
		if ( ! empty( $new_instance['embed_7'] ) ) {
			$instance['embed_7'] = sanitize_text_field( $new_instance['embed_7'] );
		}
		if ( ! empty( $new_instance['embed_8'] ) ) {
			$instance['embed_8'] = sanitize_text_field( $new_instance['embed_8'] );
		}
		if ( ! empty( $new_instance['embed_9'] ) ) {
			$instance['embed_9'] = sanitize_text_field( $new_instance['embed_9'] );
		}
		if ( ! empty( $new_instance['embed_10'] ) ) {
			$instance['embed_10'] = sanitize_text_field( $new_instance['embed_10'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'api' => '',
			'embed_1' => '',
			'embed_2' => '',
			'embed_3' => '',
			'embed_4' => '',
			'embed_5' => '',
			'embed_6' => '',
			'embed_7' => '',
			'embed_8' => '',
			'embed_9' => '',
			'embed_10' => '',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Url Embed Youtube</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'api' ); ?>">Api Youtube</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'api' ); ?>" name="<?php echo $this->get_field_name( 'api' ); ?>" value="<?php echo $instance['api']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_1' ); ?>">URL Youtube 1</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_1' ); ?>" name="<?php echo $this->get_field_name( 'embed_1' ); ?>" value="<?php echo $instance['embed_1']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_2' ); ?>">URL Youtube 2</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_2' ); ?>" name="<?php echo $this->get_field_name( 'embed_2' ); ?>" value="<?php echo $instance['embed_2']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_3' ); ?>">URL Youtube 3</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_3' ); ?>" name="<?php echo $this->get_field_name( 'embed_3' ); ?>" value="<?php echo $instance['embed_3']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_4' ); ?>">URL Youtube 4</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_4' ); ?>" name="<?php echo $this->get_field_name( 'embed_4' ); ?>" value="<?php echo $instance['embed_4']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_5' ); ?>">URL Youtube 5</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_5' ); ?>" name="<?php echo $this->get_field_name( 'embed_5' ); ?>" value="<?php echo $instance['embed_5']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_6' ); ?>">URL Youtube 6</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_6' ); ?>" name="<?php echo $this->get_field_name( 'embed_6' ); ?>" value="<?php echo $instance['embed_6']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_7' ); ?>">URL Youtube 7</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_7' ); ?>" name="<?php echo $this->get_field_name( 'embed_7' ); ?>" value="<?php echo $instance['embed_7']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_8' ); ?>">URL Youtube 8</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_8' ); ?>" name="<?php echo $this->get_field_name( 'embed_8' ); ?>" value="<?php echo $instance['embed_8']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_9' ); ?>">URL Youtube 9</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_9' ); ?>" name="<?php echo $this->get_field_name( 'embed_9' ); ?>" value="<?php echo $instance['embed_9']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'embed_10' ); ?>">URL Youtube 10</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'embed_10' ); ?>" name="<?php echo $this->get_field_name( 'embed_10' ); ?>" value="<?php echo $instance['embed_10']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function slidervideoload() {
	register_widget( 'slidervideo' );
}
add_action( 'widgets_init', 'slidervideoload' );
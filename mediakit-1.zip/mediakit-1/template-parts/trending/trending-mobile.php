<main class="main">
  <div class="container">
    <div class="row">
      <div class="col-12">

     <div class="widget terkini">
        <div class="widget-header">
          <h3 class="title"><?php the_title(); ?></h3>
        </div>
        <div class="widget-content">
            <?php the_content();?>
        </div>
       </div>
      </div>
      <aside class="col-12">
      <?php 
      if (is_active_sidebar('sidebar_area')) :
        dynamic_sidebar('sidebar_area');
      endif;
      ?>
      </aside>
    </div>
  </div>
</main>
<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
    require "header-amp.php";
}elseif (wp_is_mobile()) {
    require "header-mobile.php";
}else{
    require "header-desktop.php";
}
?>
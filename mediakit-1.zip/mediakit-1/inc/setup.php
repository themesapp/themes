<?php 
if ( ! function_exists( 'setup' ) ) :
    function setup() {
        load_theme_textdomain( 'web' );
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'title-tag' );
        add_theme_support( 'custom-logo', array(
            'height'      => 50,
            'width'       => 288,
            'flex-height' => true,
            'flex-width'  => true,
            'header-text' => array( 'brand-title', 'brand-description' ),
        ) );
        add_theme_support( 'post-thumbnails' );
        add_image_size( 'image_640_360', 640, 360, array( 'center', 'center' ));
        add_image_size( 'image_185_111', 185, 111, array( 'center', 'center' ));
        add_image_size( 'image_226_136', 226, 136, array( 'center', 'center' ));
        add_image_size( 'image_211_211', 211, 211, array( 'center', 'center' ));
        add_image_size( 'image_188_113', 188, 133, array( 'center', 'center' ));
        add_image_size( 'image_230_136', 230, 136, array( 'center', 'center' ));

        add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style', ) );
        add_theme_support('post-formats', array('aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat', ) );
        add_theme_support( 'editor-styles' );
        add_theme_support( 'wp-block-styles' );
        add_theme_support( 'responsive-embeds' );
        add_theme_support( 'customize-selective-refresh-widgets' );
    }
endif;
add_action( 'after_setup_theme', 'setup' );
?>
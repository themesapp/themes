    var base_url = window.location;    
    var url = new URL(base_url);
    var c = url.searchParams.get("daterange");
    if(c != null){
        var daterange = c;
    }else{
        var daterange = "";
    }
    jQuery(document).ready(function( $ ) {

        var start = moment('1970-01-01');
        var end = moment();

        if(daterange != "") {
            arr_daterange = daterange.split(" - ");
            start = moment(arr_daterange[0]);
            end = moment(arr_daterange[1]);
        }
        function cb(start, end) {
            $('#reportrange span').html(start.format('YYYY-MM-DD') + ' - ' + end.format('YYYY-MM-DD'));
        }

        $('#reportrange').daterangepicker({
            startDate: start,
            endDate: end,
            ranges: {
			'Semua': [moment('1970-01-01'), moment()],
            'Hari Ini': [moment(), moment()],
            'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            '7 Hari yang lalu': [moment().subtract(6, 'days'), moment()],
            'Sebulan yang lalu': [moment().subtract(29, 'days'), moment()],
            'Bulan Ini': [moment().startOf('month'), moment().endOf('month')],
            }
        }, cb);

        cb(start, end);

        $("#daterange").bind("DOMSubtreeModified", function (event) {
            if($("#daterange").text() != ""){
                    window.location.href = "?daterange=" + $("#daterange").text();
            }
        });

    });
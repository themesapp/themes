<?php
function slideroutlineViewDesktop($title,$category, $tag, $berdasarkan, $jml){
	global $post;
	//Jika kategori saja
	if($tag == "" || $tag == "-1"):
		if(!empty($category) && $category != "-1"):
			if($berdasarkan == "random"):
				$args = array(
					'category_name' => $category,
					'post_type' => 'post',
					'post_status' => 'publish',
					'orderby' => 'rand',
		    	'order'   => 'DESC',
					'posts_per_page'=> $jml
				);
				print_r($args);
			elseif($berdasarkan == "terbaru"):
				$args = array(
					'category_name' => $category,
					'post_type' => 'post',
					'post_status' => 'publish',
					'posts_per_page'=> $jml
				);
			endif;
		endif;
	endif;

	if($category == "" || $category == "-1"):
		if(!empty($tag) && $tag != "-1"):
			if($berdasarkan == "random"):
				$args = array(
					'tag' => $tag,
					'post_type' => 'post',
					'post_status' => 'publish',
					'orderby' => 'rand',
		    	'order'   => 'DESC',
					'posts_per_page'=> $jml
				);
			elseif($berdasarkan == "terbaru"):
				$args = array(
					'tag' => $tag,
					'post_type' => 'post',
					'post_status' => 'publish',
					'posts_per_page'=> $jml
				);
			endif;
		endif;
	endif;

	if($category == "" || $category == "-1"):
		if($tag == "" || $tag == "-1"):
			if($berdasarkan == "random"):
			$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'orderby' => 'rand',
		    'order'   => 'DESC',
				'posts_per_page'=> $jml
			);
			elseif($berdasarkan == "terbaru"):
			$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'posts_per_page'=> $jml
			);
			endif;
		endif;
	endif;


	if($category != "" && $category != "-1"):
		if($tag != "" && $tag != "-1"):
			if($berdasarkan == "random"):
			$args = array(
				'category_name' => $category,
				'tag' => $tag,
				'post_type' => 'post',
				'post_status' => 'publish',
				'orderby' => 'rand',
		    'order'   => 'DESC',
				'posts_per_page'=> $jml
			);
			elseif($berdasarkan == "terbaru"):
			$args = array(
				'category_name' => $category,
				'tag' => $tag,
				'post_type' => 'post',
				'post_status' => 'publish',
				'posts_per_page'=> $jml
			);
			endif;
		endif;
	endif;
	
	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>

		        <section class="network clearfix">
			        <?php if(!empty($title)): ?>
			          <h3 class="title">
			            <span><?php echo $title; ?></span>
			          </h3>
			      <?php endif; ?>
		          <div class="network__wrap js--network">
				<?php
				while ( $my_query->have_posts() ) {
					$my_query->the_post();
					?>
		                <div class="network__item">
		                  <div class="network__img">
		                    <h4 class="network__city">
		                      <a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a>
		                    </h4>
		                    <a href="<?php echo get_permalink(); ?>">
		              			<?php echo customthumbnail($post->ID, "image_226_136"); ?>
		                    </a>
		                  </div>
		                  <div class="network__box">
		                    <h2 class="network__title">
		                      <a href="<?php echo get_permalink(); ?>" class="network__link"><?php echo get_the_title(); ?></a>
		                    </h2>
		                    <date class="network__date"><?php echo timeago(); ?></date>
		                  </div>
		                </div>
					<?php
					}
					wp_reset_postdata();
					?>

		          </div>
		        </section>

	<?php endif;
}
function slideroutlineViewMobile($title,$category, $tag, $berdasarkan, $jml){
	global $post;
	//Jika kategori saja
	if($tag == "" || $tag == "-1"):
		if(!empty($category) && $category != "-1"):
			if($berdasarkan == "random"):
				$args = array(
					'category_name' => $category,
					'post_type' => 'post',
					'post_status' => 'publish',
					'orderby' => 'rand',
		    	'order'   => 'DESC',
					'posts_per_page'=> $jml
				);
				print_r($args);
			elseif($berdasarkan == "terbaru"):
				$args = array(
					'category_name' => $category,
					'post_type' => 'post',
					'post_status' => 'publish',
					'posts_per_page'=> $jml
				);
			endif;
		endif;
	endif;

	if($category == "" || $category == "-1"):
		if(!empty($tag) && $tag != "-1"):
			if($berdasarkan == "random"):
				$args = array(
					'tag' => $tag,
					'post_type' => 'post',
					'post_status' => 'publish',
					'orderby' => 'rand',
		    	'order'   => 'DESC',
					'posts_per_page'=> $jml
				);
			elseif($berdasarkan == "terbaru"):
				$args = array(
					'tag' => $tag,
					'post_type' => 'post',
					'post_status' => 'publish',
					'posts_per_page'=> $jml
				);
			endif;
		endif;
	endif;

	if($category == "" || $category == "-1"):
		if($tag == "" || $tag == "-1"):
			if($berdasarkan == "random"):
			$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'orderby' => 'rand',
		    'order'   => 'DESC',
				'posts_per_page'=> $jml
			);
			elseif($berdasarkan == "terbaru"):
			$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'posts_per_page'=> $jml
			);
			endif;
		endif;
	endif;


	if($category != "" && $category != "-1"):
		if($tag != "" && $tag != "-1"):
			if($berdasarkan == "random"):
			$args = array(
				'category_name' => $category,
				'tag' => $tag,
				'post_type' => 'post',
				'post_status' => 'publish',
				'orderby' => 'rand',
		    'order'   => 'DESC',
				'posts_per_page'=> $jml
			);
			elseif($berdasarkan == "terbaru"):
			$args = array(
				'category_name' => $category,
				'tag' => $tag,
				'post_type' => 'post',
				'post_status' => 'publish',
				'posts_per_page'=> $jml
			);
			endif;
		endif;
	endif;

	$my_query = new WP_Query( $args );
	if ( $my_query->have_posts() ): ?>

        <section class="network clearfix">
	        <?php if(!empty($title)): ?>
	          <h3 class="title">
	            <span><?php echo $title; ?></span>
	          </h3>
	      <?php endif; ?>
          <div class="network__wrap js--network">
		<?php
		while ( $my_query->have_posts() ) {
			$my_query->the_post();
			?>
                <div class="network__item">
                  <div class="network__img">
                    <h4 class="network__city">
                      <a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a>
                    </h4>
                    <a href="<?php echo get_permalink(); ?>">
              			<?php echo customthumbnail($post->ID, "image_230_136"); ?>
                    </a>
                  </div>
                  <div class="network__box">
                    <h2 class="network__title">
                      <a href="<?php echo get_permalink(); ?>" class="network__link"><?php echo get_the_title(); ?></a>
                    </h2>
                    <date class="network__date"><?php echo timeago(); ?></date>
                  </div>
                </div>
			<?php
			}
			wp_reset_postdata();
			?>

          </div>
        </section>

	<?php endif;
}
class slideroutline extends WP_Widget {

	public function __construct() {
		$idwidget = 'slideroutline';
		$namewidget = '📌 Slider Warna';
		$descwidget = 'Slider yang bisa disesuaikan warnanya berdasarkan kategori yang dipilih dan ditampilkan dalam bentuk slider di Beranda.';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				slideroutlineViewMobile($instance['title'], $instance['category'], $instance['tag'], $instance['berdasarkan'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				slideroutlineViewMobile($instance['title'], $instance['category'], $instance['tag'], $instance['berdasarkan'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				slideroutlineViewDesktop($instance['title'], $instance['category'], $instance['tag'], $instance['berdasarkan'], $instance['amountmobile']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['category'] ) ) {
			$instance['category'] = sanitize_text_field( $new_instance['category'] );
		}
		if ( ! empty( $new_instance['tag'] ) ) {
			$instance['tag'] = sanitize_text_field( $new_instance['tag'] );
		}
			$instance['berdasarkan'] = sanitize_text_field( $new_instance['berdasarkan'] );
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'category' => '-1',
			'tag' => '-1',
			'berdasarkan' => 'terbaru',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>

		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Widget</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php echo 'Kategori:'; ?></label>
				<select id="<?php echo $this->get_field_id('category'); ?>" name="<?php echo $this->get_field_name('category'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['category'], "-1" ); ?> value="-1">Pilih Kategori</option>
					<?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { ?>
						<option <?php selected( $instance['category'], $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
					<?php } ?>      
				</select>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'tag' ); ?>"><?php echo 'Tag:'; ?></label>
				<select id="<?php echo $this->get_field_id('tag'); ?>" name="<?php echo $this->get_field_name('tag'); ?>" class="widefat" style="width:100%;" required>
					<option <?php selected( $instance['tag'], "-1" ); ?> value="-1">Pilih Tag</option>
					<?php foreach(get_terms('post_tag','parent=0&hide_empty=0') as $term) { ?>
						<option <?php selected( $instance['tag'], $term->slug ); ?> value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
					<?php } ?>      
				</select>
			</p>

      <p>
				<label><?php echo 'Tampilkan berdasarkan:'; ?></label><br/>
          <input type="radio" value="terbaru" name="<?php echo $this->get_field_name( 'berdasarkan' ); ?>" <?php checked( $instance['berdasarkan'], 'terbaru' ); ?> id="<?php echo $this->get_field_id( 'terbaru' ); ?>" />
					<label for="<?php echo $this->get_field_id( 'terbaru' ); ?>">Terbaru</label><br/>

          <input type="radio" value="random" name="<?php echo $this->get_field_name( 'berdasarkan' ); ?>" <?php checked( $instance['berdasarkan'], 'random' ); ?> id="<?php echo $this->get_field_id( 'random' ); ?>" />
					<label for="<?php echo $this->get_field_id( 'random' ); ?>">Random</label><br/>

      </p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo 'Jumlah pos di desktop:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" min="1" max="10" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo 'Jumlah pos di mobile:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" min="1" max="10" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function slideroutlineload() {
	register_widget( 'slideroutline' );
}
add_action( 'widgets_init', 'slideroutlineload' ); 
?>
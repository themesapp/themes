<?php
function feednetworkbodyViewDesktop($title,$nama,$feed,$start,$jml){
	if(!empty($nama)):
		$response = wp_remote_get( $feed . 'posts/?per_page=' . $jml .'&offset=' . $start .'&status=publish&type=post' );
	endif;
	$posts = json_decode( wp_remote_retrieve_body( $response ) );
	if ( is_array( $response ) && ! is_wp_error( $response ) ) {
	   if( !empty( $posts ) ) { 
	   	?>
    <section class="latest mt3 clearfix">
      <?php if(!empty($title)): ?>
        <h3 class="title">
          <span><?php echo $title; ?></span>
        </h3>
    <?php endif; ?>
      <div class="latest__wrap">
        <?php
			foreach( $posts as $post ) {
				$t = strtotime($post->date);
				if ( ! empty( $post->featured_media ) ) {
					$thumb_id = $post->featured_media;
					$responsethumb = wp_remote_get( $feed . 'media/' . $thumb_id );
					$thumb = json_decode( wp_remote_retrieve_body( $responsethumb ) );

				}
          ?>
          <div class="latest__item">
            <div class="latest__img">
              <a href="<?php echo $post->link ?>">
				<img src="<?php echo $thumb->media_details->sizes->image_188_113->source_url; ?>" alt="<?php echo $post->title->rendered; ?>" />
              </a>
            </div>
            <div class="latest__right">
              <h4 class="latest__subtitle">
                <?php echo $nama; ?>
              </h4>
              <h2 class="latest__title">
				<a href="<?php echo $post->link ?>" class="latest__link" target="_blank"><?php echo $post->title->rendered; ?></a>
              </h2>
              <date class="latest__date"><?php echo date_i18n(get_option("date_format") .' |' . get_option("time_format"), $t); ?></date>
            </div>
          </div>
          <?php
          }
          ?>
      </div>
    </section>

	      <?php
	   }
	}
}
function feednetworkbodyViewMobile($title,$nama,$feed,$start,$jml){

	if(!empty($nama)):
		$response = wp_remote_get( $feed . 'posts/?per_page=' . $jml .'&offset=' . $start .'&status=publish&type=post' );
	endif;
	$posts = json_decode( wp_remote_retrieve_body( $response ) );
	if ( is_array( $response ) && ! is_wp_error( $response ) ) {
	   if( !empty( $posts ) ) { 
	   	?>
    <section class="latest clearfix">
      <?php if(!empty($title)): ?>
        <h3 class="title">
          <span><?php echo $title; ?></span>
        </h3>
    <?php endif; ?>
      <div class="latest__wrap">
        <?php
			foreach( $posts as $post ) {
				$t = strtotime($post->date);
				if ( ! empty( $post->featured_media ) ) {
					$thumb_id = $post->featured_media;
					$responsethumb = wp_remote_get( $feed . 'media/' . $thumb_id );
					$thumb = json_decode( wp_remote_retrieve_body( $responsethumb ) );

				}
          ?>
          <div class="latest__item">
            <div class="latest__img">
              <a href="<?php echo $post->link ?>">
				<img src="<?php echo $thumb->media_details->sizes->image_188_113->source_url; ?>" alt="<?php echo $post->title->rendered; ?>" />
              </a>
            </div>
            <div class="latest__right">
              <h2 class="latest__title">
				<a href="<?php echo $post->link ?>" class="latest__link" target="_blank"><?php echo $post->title->rendered; ?></a>
              </h2>
              <h4 class="latest__subtitle">
                <?php echo $nama; ?>
              </h4>
              <date class="latest__date"><?php echo date_i18n(get_option("date_format") .' |' . get_option("time_format"), $t); ?></date>
            </div>
          </div>
          <?php
          }
          ?>
      </div>
    </section>

	      <?php
	   }
	}
}
class feednetworkbodyWidget extends WP_Widget {

	public function __construct() {
		$idwidget = 'feednetworkbody';
		$namewidget = '📌 Feed Network Body';
		$descwidget = 'Daftar pos terbaru yang ditampilkan dalam box beranda (bukan siderbar).';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				feednetworkbodyViewMobile($instance['title'],$instance['nama'],$instance['urlfeed'], $instance['start'], $instance['amountmobile']);
			}elseif (wp_is_mobile()) {
				feednetworkbodyViewMobile($instance['title'],$instance['nama'],$instance['urlfeed'], $instance['start'], $instance['amountmobile']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				feednetworkbodyViewDesktop($instance['title'],$instance['nama'],$instance['urlfeed'], $instance['start'], $instance['amountdesktop']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['nama'] ) ) {
			$instance['nama'] = sanitize_text_field( $new_instance['nama'] );
		}
		if ( ! empty( $new_instance['urlfeed'] ) ) {
			$instance['urlfeed'] = sanitize_text_field( $new_instance['urlfeed'] );
		}
    if ( ! empty( $new_instance['start'] ) ) {
      $instance['start'] = sanitize_text_field( $new_instance['start'] );
    }
		if ( ! empty( $new_instance['amountdesktop'] ) ) {
			$instance['amountdesktop'] = sanitize_text_field( $new_instance['amountdesktop'] );
		}
		if ( ! empty( $new_instance['amountmobile'] ) ) {
			$instance['amountmobile'] = sanitize_text_field( $new_instance['amountmobile'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}
	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'nama' => '',
			'urlfeed' => '/wp-json/wp/v2/',
      		'start' => '1',
			'amountdesktop' => '3',
			'amountmobile' => '3',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Network</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'nama' ); ?>">Nama Network</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'nama' ); ?>" name="<?php echo $this->get_field_name( 'nama' ); ?>" value="<?php echo $instance['nama']; ?>" />
			</p>
			<h3>Pengaturan Feed</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'urlfeed' ); ?>">URL Api Network</label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'urlfeed' ); ?>" name="<?php echo $this->get_field_name( 'urlfeed' ); ?>" value="<?php echo $instance['urlfeed']; ?>" />
			</p>
      <p>
        <label for="<?php echo $this->get_field_id( 'start' ); ?>">Dimulai pos ke:</label>
        <input type="number" class="widefat" id="<?php echo $this->get_field_id( 'start' ); ?>" name="<?php echo $this->get_field_name( 'start' ); ?>" min="1" value="<?php echo $instance['start']; ?>" required/>
      </p>
			<hr>
			<h3>Pengaturan Widget</h3>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountdesktop' ); ?>"><?php echo 'Jumlah pos di desktop:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountdesktop' ); ?>" name="<?php echo $this->get_field_name( 'amountdesktop' ); ?>" min="1" max="10" value="<?php echo $instance['amountdesktop']; ?>" required/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'amountmobile' ); ?>"><?php echo 'Jumlah pos di mobile:'; ?></label>
				<input type="number" class="widefat" id="<?php echo $this->get_field_id( 'amountmobile' ); ?>" name="<?php echo $this->get_field_name( 'amountmobile' ); ?>" min="1" max="10" value="<?php echo $instance['amountmobile']; ?>" required/>
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function feednetworkbodyWidgetload() {
	register_widget( 'feednetworkbodyWidget' );
}
add_action( 'widgets_init', 'feednetworkbodyWidgetload' );
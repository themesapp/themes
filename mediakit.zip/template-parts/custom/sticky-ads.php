<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
}elseif (wp_is_mobile()) {
}else{
?>
<div class="row ads__stick__wrap clearfix">
  <div class="kcm ads__stick js--stick">
	<?php if (is_active_sidebar('sticky_ads_left')) :?>
    <div class="ads__stick__fluid ads__stick__fluid--left">
      <div class="ads__stick--left">
      	<?php dynamic_sidebar('sticky_ads_left'); ?>
      </div>
    </div>
    <?php endif; ?>
	<?php if (is_active_sidebar('sticky_ads_right')) :?>
    <div class="ads__stick__fluid ads__stick__fluid--right">
      <div class="ads__stick--right">
      	<?php dynamic_sidebar('sticky_ads_right'); ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php } ?>
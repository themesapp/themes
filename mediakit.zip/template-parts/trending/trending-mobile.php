<div class="row clearfix">
  <div class="container clearfix">
        <!-- latest -->
        <section class="page clearfix">
          <h3 class="title">
            <span><?php the_title(); ?></span>
          </h3>
            <?php the_content();?>
            <?php 
            if($my_query->max_num_pages > 1):
             ?>
              <div class="paging paging--page clearfix">
                <div class="paging__wrap clearfix">
                  <?php
                $big = 999999999; // need an unlikely integer
                 
                echo paginate_links( array(
                    'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                    'format'  => '?paged=%#%',
                    'current' => max( 1, get_query_var('paged') ),
                    'total'   => $my_query->max_num_pages,
                    'next_text' => 'Next',
                    'prev_text' => 'Prev',
                ) );
                ?>
                </div>
              </div>
          <?php endif; ?>
        </section>
    <?php if (is_active_sidebar("sidebar_area")):
      dynamic_sidebar("sidebar_area");
  endif; ?>
  </div>
</div>
<footer class="footer">
  <div class="row footer__top container clearfix">
    <div class="col-offset-fluid clearfix">
      <div class="col-bs10-4">
        <?php
        if ( is_active_sidebar( 'footer_brand' ) ) : ?>
        <div class="footer__logo">
        <?php dynamic_sidebar('footer_brand'); ?>
        </div>
        <?php endif;
        ?>
        <?php
        if ( is_active_sidebar( 'footer_contact' ) ) : ?>
        <div class="footer__contact">
        <?php dynamic_sidebar('footer_contact'); ?>
        </div>
        <?php endif;
        ?>
      </div>
      <div class="col-bs10-2">
        <?php
        if ( is_active_sidebar( 'footer_nav' ) ) : ?>
        <div class="footer__menu">
        <?php dynamic_sidebar('footer_nav'); ?>
        </div>
        <?php endif;
        ?>
      </div>
      <div class="col-bs10-2">
        <?php
        if ( is_active_sidebar( 'footer_alternatif' ) ) : ?>
        <div class="footer__menu">
        <?php dynamic_sidebar('footer_alternatif'); ?>
        </div>
        <?php endif;
        ?>
      </div>
      <div class="col-bs10-2">
        <?php
        if ( is_active_sidebar( 'footer_email' ) ) :  ?>
        <div class="footer__menu">
        <?php dynamic_sidebar('footer_email'); ?>
        </div>
        <?php endif;
        ?>
      </div>
    </div>
  </div>
  <div class="row footer__bottom container clearfix">
    <div class="col-offset-fluid clearfix">
      <div class="col-bs10-6">
        <?php
        if ( is_active_sidebar( 'footer_left' ) ) : ?>
        <div class="footer__menu inline clearfix">
        <?php dynamic_sidebar('footer_left'); ?>
        </div>
        <?php endif;
        ?>
      </div>
      <div class="col-bs10-4">        
        <?php 
        if (is_active_sidebar('footer_right')) :?>
        <div class="footer__copyright">
        <?php dynamic_sidebar('footer_right'); ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</footer>
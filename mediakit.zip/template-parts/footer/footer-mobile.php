<footer class="footer">
    <div class="row footer__top container clearfix">
        <?php
        if ( is_active_sidebar( 'footer_brand' ) ) : ?>
        <div class="footer__logo">
        <?php dynamic_sidebar('footer_brand'); ?>
        </div>
        <?php endif;
        ?>

        <?php
        if ( is_active_sidebar( 'footer_contact' ) ) : ?>
        <div class="footer__contact">
        <?php dynamic_sidebar('footer_contact'); ?>
        </div>
        <?php endif;
        ?>
        <div class="footer__wrap__menu clearfix">
        <?php
        if ( is_active_sidebar( 'footer_nav' ) ) : ?>
        <div class="footer__menu">
        <?php dynamic_sidebar('footer_nav'); ?>
        </div>
        <?php endif;
        ?>
        </div>
        <div class="footer__wrap__menu clearfix">
        <?php
        if ( is_active_sidebar( 'footer_alternatif' ) ) : ?>
        <div class="footer__menu">
        <?php dynamic_sidebar('footer_alternatif'); ?>
        </div>
        <?php endif;
        ?>
        </div>
        <div class="footer__wrap__menu clearfix">
        <?php
        if ( is_active_sidebar( 'footer_email' ) ) : ?>
        <div class="footer__menu">
        <?php dynamic_sidebar('footer_email'); ?>
        </div>
        <?php endif;
        ?>
        </div>
      <div class="social social--footer clearfix">
      <?php if ( "" != (get_theme_mod( 'tombolfollowfacebook' ))) : ?>
        <div class="social__item">
          <a href="<?php echo get_theme_mod( 'tombolfollowfacebook' ); ?>" target="_blank" class="social__link social__link--facebook">
            <span class="icon icon-facebook"></span>
          </a>
        </div>
      <?php endif; ?>
      <?php if ( "" != (get_theme_mod( 'tombolfollowtwitter' ))) : ?>
        <div class="social__item">
          <a href="<?php echo get_theme_mod( 'tombolfollowtwitter' ); ?>" target="_blank" class="social__link social__link--twitter">
            <span class="icon icon-twitter"></span>
          </a>
        </div>
      <?php endif; ?>
      <?php if ( "" != (get_theme_mod( 'tombolfollowinstagram' ))) : ?>
        <div class="social__item">
          <a href="<?php echo get_theme_mod( 'tombolfollowinstagram' ); ?>" target="_blank" class="social__link social__link--instagram">
            <span class="icon icon-instagram"></span>
          </a>
        </div>
      <?php endif; ?>
      <?php if ( "" != (get_theme_mod( 'tombolfollowyoutube' ))) : ?>
        <div class="social__item">
          <a href="<?php echo get_theme_mod( 'tombolfollowyoutube' ); ?>" target="_blank" class="social__link social__link--rss">
            <span class="icon icon-youtube"></span>
          </a>
        </div>
      <?php endif; ?>
  </div>
        <div class="row footer__bottom clearfix">
        <?php
        if ( is_active_sidebar( 'footer_left' ) ) : ?>
        <div class="footer__menu inline clearfix">
        <?php dynamic_sidebar('footer_left'); ?>
        </div>
        <?php endif;
        ?>
        <?php 
        if (is_active_sidebar('footer_right')) :?>
        <div class="footer__copyright">
        <?php dynamic_sidebar('footer_right'); ?>
        </div>
        <?php endif; ?>
        </div>
    </div>
</footer>
<nav class="nav -hide" id="js--nav">
    <div class="nav__scroll">
              <?php
              if ( has_nav_menu( 'sidebarmenu' ) ) : 
                sidebarmenu();
              endif;
              ?>
            <?php
            if ( has_nav_menu( 'network_menu' ) ) : 
              ?>
              <h3 class="title"><?php echo wp_get_nav_menu_name('network_menu') ?></h3>
                  <?php
                  network_menu();
                  ?>
              <?php
            endif;
            ?>
          <div class="social__nav text-center">
            <?php if ( "" != (get_theme_mod( 'tombolfollowfacebook' ))) : ?>
              <div class="social__item">
                <a href="<?php echo get_theme_mod( 'tombolfollowfacebook' ); ?>" target="_blank" class="social__link social__link--facebook">
                  <span class="icon icon-facebook"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowtwitter' ))) : ?>
              <div class="social__item">
                <a href="<?php echo get_theme_mod( 'tombolfollowtwitter' ); ?>" target="_blank" class="social__link social__link--twitter">
                  <span class="icon icon-twitter"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowinstagram' ))) : ?>
              <div class="social__item">
                <a href="<?php echo get_theme_mod( 'tombolfollowinstagram' ); ?>" target="_blank" class="social__link social__link--instagram">
                  <span class="icon icon-instagram"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowyoutube' ))) : ?>
              <div class="social__item">
                <a href="<?php echo get_theme_mod( 'tombolfollowyoutube' ); ?>" target="_blank" class="social__link social__link--rss">
                  <span class="icon icon-youtube"></span>
                </a>
              </div>
            <?php endif; ?>
        </div>
		
        <?php 
        if (is_active_sidebar('footer_right')) :?>
        <div class="sidebar_copyright">
        <?php dynamic_sidebar('footer_right'); ?>
        </div>
        <?php endif; ?>
    </div>
    <div class="nav__overlay"></div>
</nav>
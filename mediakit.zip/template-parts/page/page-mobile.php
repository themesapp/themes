<div class="row clearfix">
  <div class="container clearfix">
		  <!-- header -->
			<?php 
			if (have_posts()):
			while (have_posts()): the_post();
			?>
		  <section class="read__header mt3 clearfix">
		      <h1 class="read__title"><?php the_title(); ?></h1>
		      <div class="read__info">
		        <div class="read__info__author">
				  <a href="<?php echo get_author_posts_url(
		        get_the_author_meta("ID")
		    ); ?>"><?php echo get_the_author(); ?></a>
		        </div>
		        <div class="read__info__date"> - <?php echo get_the_date(
		            get_option("date_format")
		        ); ?> | <?php echo get_the_time(get_option("time_format")); ?> </div>
		      </div>
		 

			<?php if ( !has_post_format('image') &&  !has_post_format('video') ): ?>
		      <?php if (has_post_thumbnail(get_the_ID())): ?>
			      <div class="photo">
			        <div class="photo__img">
						<?php
		    echo get_the_post_thumbnail($post_id, "full", [
		        "class" => "featured-image",
		    ]);
		    $caption = get_post(get_post_thumbnail_id())->post_excerpt;
		    ?>
				        </div>
				        <div class="photo__caption">
						<?php if (!empty($caption)) { ?>
								<figcaption><?php echo $caption; ?></figcaption>
						<?php } ?>
			      </div>
			    </div>
				<?php endif; ?>
				<?php endif; ?>
		  </section>
		  <div class="read__article clearfix js--tower-parent">
		    <div class="col-offset-0">
		      <!-- content -->
		      <article class="read__content clearfix">
				<?php the_content(); ?>
		      </article>
				<?php
		  global $page, $pages;
		  if (count($pages) > 1): ?>
			      <div class="read__paging clearfix">
			        <div class="paging paging--article clearfix">
			          <div class="paging__teaser">Halaman: </div>
			          <div class="paging__wrap clearfix">
							<?php
		     wp_link_pages("before=&after=");
		     if ($page == count($pages)):
		         wp_link_pages(
		             'before=<div class="paging__nextprev">&after=</div>&nextpagelink=&next_or_number=next&previouspagelink=<span class="btn-next">Sebelumnya</span>'
		         );
		     else:
		         wp_link_pages(
		             'before=<div class="paging__nextprev">&after=</div>&nextpagelink=<span class="btn-next">Selanjutnya</span>&next_or_number=next&previouspagelink='
		         );
		     endif;
		     ?>
			        	</div>
			        </div>
			      </div>
				<?php endif;
		  ?>
			<div class="more_article">
				<div class="more_left">			
				<?php if (true == get_theme_mod("sumber", true)): ?>
					<?php if (!empty($info["sumber"])): ?>
				      <p>Sumber : <?php echo $info["sumber"]; ?></p>
					<?php endif; ?>
			    <?php endif; ?>
				<?php if (true == get_theme_mod("editor", true)): ?>
					<?php if (!empty($info["editor"]) && $info["editor"] != "-1"): ?>
				      <p>Editor : <?php echo get_author_name($info["editor"]); ?></p>
					<?php endif; ?>
			    <?php endif; ?>
				</div>
				<div class="more_right">
					<div class="social social--article clearfix">
					<div class="social_title">Bagikan:</div>
					<?php if (true == get_theme_mod("tombolfacebook", true)): ?>
			        <div class="social__item">
			          <a href="https://web.facebook.com/sharer/sharer.php?u=<?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social__link social__link--facebook">
			            <span class="icon icon-facebook"></span>
			          </a>
			        </div>
					<?php endif; ?>
					<?php if (true == get_theme_mod("tomboltwitter", true)): ?>
			        <div class="social__item">
			          <a href="https://twitter.com/intent/tweet?text<?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social__link social__link--twitter">
			            <span class="icon icon-twitter"></span>
			          </a>
			        </div>
					<?php endif; ?>
					<?php if (true == get_theme_mod("tombolwhatsapp", true)): ?>
			        <div class="social__item">
			          <a href="https://api.whatsapp.com/send/?text=<?php echo get_the_title(); ?> | <?php echo get_the_permalink(); ?>" target="_blank" rel="nofollow" class="social__link social__link--whatsapp">
			            <span class="icon icon-whatsapp"></span>
			          </a>
			        </div>
					<?php endif; ?>
					    
					</div>
				</div>
			</div>

		    </div>
		  </div>
				<?php
				endwhile;
				endif; ?>
		<?php if (is_active_sidebar("sidebar_area")):
      dynamic_sidebar("sidebar_area");
  endif; ?>
  </div>
</div>
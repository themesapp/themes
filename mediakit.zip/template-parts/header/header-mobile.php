<?php if(!empty(get_theme_mod( 'header' ))):
if(get_theme_mod( 'header' ) == "header2"):
?>

<header class="header header2">
    <div class="header__top">
        <div class="menu menu--right clearfix">
            <div class="menu__item">
              <button class="mode">
                <span class="dark"></span>
              </button>
            </div>
        </div>
        <div class="menu menu--right clearfix">
            <div class="menu__item">
                <a href="#" class="menu__link" id="js--search">
                    <span class="icon icons-search"></span>
                </a>
            </div>
        </div>
          <div class="logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
        <div class="menu menu--left clearfix">
            <div class="menu__item">
                <a href="#sidr" class="menu__link icon-bar" id="js--menu">
                    <i></i>
                </a>
            </div>
        </div>
    </div>
    <div class="header__bottom">
        <div class="row container clearfix">
              <form class="search__bar" method="get" action="<?php echo home_url('/'); ?>">
                  <input class="search__input" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
                  <input type="hidden" name="post_type" value="post" />
                  <span class="icon icon-search"></span>
              </form>
        </div>
        <div class="search__overlay"></div>
    </div>
    <div class="header__scroll">
        <div class="header__scroll__slide">
            <div class="header__scroll__wrap">
                  <?php
                  if ( has_nav_menu( 'mobile_menu' ) ) : 
                    mobile_menu();
                  endif;
                  ?>
            </div>
        </div>
    </div>
</header>
<?php
else:
?>
<header class="header">
    <div class="header__top">
          <div class="logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
        <div class="menu menu--right clearfix">
            <div class="menu__item">
              <button class="mode">
                <span class="dark"></span>
              </button>
            </div>
        </div>
        <div class="menu menu--right clearfix">
            <div class="menu__item">
                <a href="#" class="menu__link" id="js--search">
                    <span class="icon icons-search"></span>
                </a>
            </div>
        </div>
        <div class="menu menu--left clearfix">
            <div class="menu__item">
                <a href="#sidr" class="menu__link icon-bar" id="js--menu">
                    <i></i>
                </a>
            </div>
        </div>
    </div>
    <div class="header__bottom">
        <div class="row container clearfix">
              <form class="search__bar" method="get" action="<?php echo home_url('/'); ?>">
                  <input class="search__input" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
                  <input type="hidden" name="post_type" value="post" />
                  <span class="icon icon-search"></span>
              </form>
        </div>
        <div class="search__overlay"></div>
    </div>
    <div class="header__scroll">
        <div class="header__scroll__slide">
            <div class="header__scroll__wrap">
                  <?php
                  if ( has_nav_menu( 'mobile_menu' ) ) : 
                    mobile_menu();
                  endif;
                  ?>
            </div>
        </div>
    </div>
</header>
<?php
endif;
?>
<?php else: ?>
<header class="header">
    <div class="header__top">
          <div class="logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
        <div class="menu menu--right clearfix">
            <div class="menu__item">
              <button class="mode">
                <span class="dark"></span>
              </button>
            </div>
        </div>
        <div class="menu menu--right clearfix">
            <div class="menu__item">
                <a href="#" class="menu__link" id="js--search">
                    <span class="icon icons-search"></span>
                </a>
            </div>
        </div>
        <div class="menu menu--left clearfix">
            <div class="menu__item">
                <a href="#sidr" class="menu__link icon-bar" id="js--menu">
                    <i></i>
                </a>
            </div>
        </div>
    </div>
    <div class="header__bottom">
        <div class="row container clearfix">
              <form class="search__bar" method="get" action="<?php echo home_url('/'); ?>">
                  <input class="search__input" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
                  <input type="hidden" name="post_type" value="post" />
                  <span class="icon icon-search"></span>
              </form>
        </div>
        <div class="search__overlay"></div>
    </div>
    <div class="header__scroll">
        <div class="header__scroll__slide">
            <div class="header__scroll__wrap">
                  <?php
                  if ( has_nav_menu( 'mobile_menu' ) ) : 
                    mobile_menu();
                  endif;
                  ?>
            </div>
        </div>
    </div>
</header>
<?php endif; ?>
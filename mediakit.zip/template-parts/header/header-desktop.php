<?php if(!empty(get_theme_mod( 'header' ))):
if(get_theme_mod( 'header' ) == "header2"):
?>
<header class="header header2">
  <div class="header__middle">
    <div class="row container clearfix">
      <div class="col-offset-fluid clearfix">
        <div class="col-bs12-4">
          <div class="logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
        </div>
        <div class="col-bs12-7">
          <ul class="network__menu">
            <li>
              <date><?php $date = date_i18n( get_option( 'date_format' ), strtotime( get_the_date( 'r' ) ) ); echo $date ;?></date>
            </li>
              <?php
              if ( has_nav_menu( 'network_menu' ) ) : 
                ?>
                <li class="network_wrap">
                    <a href="#">
                    <i class="icons icon-small mr1 icons-category"></i> <?php echo wp_get_nav_menu_name('network_menu') ?> </a>
                    <?php
                    network_menu();
                    ?>
                </li>
                <?php
              endif;
              ?>
            <li class="space-brand">
            </li>
            <li>
              <button class="mode">
                <span class="dark"></span>
              </button>
            <li>
              <a href="#">
                <span class="icon icon-small icons-search"></span>
              </a>
              <ul class="text-center w-200">
                <li class="network__menu__search">
                  <form class="search__bar" method="get" action="<?php echo home_url('/'); ?>">
                      <input class="search__input" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
                      <input type="hidden" name="post_type" value="post" />
                      <input type="submit" class="search__submit"/>
                      <span class="icon icon-search"></span>
                  </form>
                </li>
              </ul>
            </li>
            <li>
              <div class="social social--header clearfix">
              <?php if ( "" != (get_theme_mod( 'tombolfollowfacebook' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowfacebook' ); ?>" target="_blank" class="social__link social__link--facebook">
                    <span class="icon icon-facebook"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowtwitter' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowtwitter' ); ?>" target="_blank" class="social__link social__link--twitter">
                    <span class="icon icon-twitter"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowinstagram' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowinstagram' ); ?>" target="_blank" class="social__link social__link--instagram">
                    <span class="icon icon-instagram"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowyoutube' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowyoutube' ); ?>" target="_blank" class="social__link social__link--rss">
                    <span class="icon icon-youtube"></span>
                  </a>
                </div>
              <?php endif; ?>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="header__bottom">
    <div class="row container clearfix">
      <div class="col-offset-fluid clearfix">
        <div class="col-bs10-10">
          <nav class="nav">
            <div class="nav__home">
              <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="Home">
                <span class="icon icon-xsmall icons-home"></span>
              </a>
            </div>
              <?php
              if ( has_nav_menu( 'menu_utama' ) ) : 
                menu_utama();
              endif;
              ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>
<?php
else:
?>
<header class="header">
  <div class="header__middle">
    <div class="row container clearfix">
      <div class="col-offset-fluid clearfix">
        <div class="col-bs12-5">
          <div class="logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
        </div>
        <div class="col-bs12-7">
          <ul class="network__menu">
            <li>
              <date><?php $date = date_i18n( get_option( 'date_format' ), strtotime( get_the_date( 'r' ) ) ); echo $date ;?></date>
            </li>
              <?php
              if ( has_nav_menu( 'network_menu' ) ) : 
                ?>
                <li class="network_wrap">
                    <a href="#">
                    <i class="icons icon-small mr1 icons-category"></i> <?php echo wp_get_nav_menu_name('network_menu') ?> </a>
                    <?php
                    network_menu();
                    ?>
                </li>
                <?php
              endif;
              ?>
            <li>
              <button class="mode">
                <span class="dark"></span>
              </button>
            <li>
              <a href="#">
                <span class="icon icon-small icons-search"></span>
              </a>
              <ul class="text-center w-200">
                <li class="network__menu__search">
                  <form class="search__bar" method="get" action="<?php echo home_url('/'); ?>">
                      <input class="search__input" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
                      <input type="hidden" name="post_type" value="post" />
                      <input type="submit" class="search__submit"/>
                      <span class="icon icon-search"></span>
                  </form>
                </li>
              </ul>
            </li>
            <li>
              <div class="social social--header clearfix">
              <?php if ( "" != (get_theme_mod( 'tombolfollowfacebook' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowfacebook' ); ?>" target="_blank" class="social__link social__link--facebook">
                    <span class="icon icon-facebook"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowtwitter' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowtwitter' ); ?>" target="_blank" class="social__link social__link--twitter">
                    <span class="icon icon-twitter"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowinstagram' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowinstagram' ); ?>" target="_blank" class="social__link social__link--instagram">
                    <span class="icon icon-instagram"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowyoutube' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowyoutube' ); ?>" target="_blank" class="social__link social__link--rss">
                    <span class="icon icon-youtube"></span>
                  </a>
                </div>
              <?php endif; ?>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="header__bottom">
    <div class="row container clearfix">
      <div class="col-offset-fluid clearfix">
        <div class="col-bs10-10">
          <nav class="nav">
            <div class="nav__home">
              <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="Home">
                <span class="icon icon-xsmall icons-home"></span>
              </a>
            </div>
              <?php
              if ( has_nav_menu( 'menu_utama' ) ) : 
                menu_utama();
              endif;
              ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>
<?php
endif;
?>
<?php else: ?>
<header class="header">
  <div class="header__middle">
    <div class="row container clearfix">
      <div class="col-offset-fluid clearfix">
        <div class="col-bs12-5">
          <div class="logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
        </div>
        <div class="col-bs12-7">
          <ul class="network__menu">
            <li>
              <date><?php $date = date_i18n( get_option( 'date_format' ), strtotime( get_the_date( 'r' ) ) ); echo $date ;?></date>
            </li>
              <?php
              if ( has_nav_menu( 'network_menu' ) ) : 
                ?>
                <li class="network_wrap">
                    <a href="#">
                    <i class="icons icon-small mr1 icons-category"></i> <?php echo wp_get_nav_menu_name('network_menu') ?> </a>
                    <?php
                    network_menu();
                    ?>
                </li>
                <?php
              endif;
              ?>
            <li>
              <button class="mode">
                <span class="dark"></span>
              </button>
            <li>
              <a href="#">
                <span class="icon icon-small icons-search"></span>
              </a>
              <ul class="text-center w-200">
                <li class="network__menu__search">
                  <form class="search__bar" method="get" action="<?php echo home_url('/'); ?>">
                      <input class="search__input" type="text" name="s" placeholder="Cari di sini..." value="<?php the_search_query(); ?>" maxlength="50" autocomplete="off">
                      <input type="hidden" name="post_type" value="post" />
                      <input type="submit" class="search__submit"/>
                      <span class="icon icon-search"></span>
                  </form>
                </li>
              </ul>
            </li>
            <li>
              <div class="social social--header clearfix">
              <?php if ( "" != (get_theme_mod( 'tombolfollowfacebook' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowfacebook' ); ?>" target="_blank" class="social__link social__link--facebook">
                    <span class="icon icon-facebook"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowtwitter' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowtwitter' ); ?>" target="_blank" class="social__link social__link--twitter">
                    <span class="icon icon-twitter"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowinstagram' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowinstagram' ); ?>" target="_blank" class="social__link social__link--instagram">
                    <span class="icon icon-instagram"></span>
                  </a>
                </div>
              <?php endif; ?>
              <?php if ( "" != (get_theme_mod( 'tombolfollowyoutube' ))) : ?>
                <div class="social__item">
                  <a href="<?php echo get_theme_mod( 'tombolfollowyoutube' ); ?>" target="_blank" class="social__link social__link--rss">
                    <span class="icon icon-youtube"></span>
                  </a>
                </div>
              <?php endif; ?>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="header__bottom">
    <div class="row container clearfix">
      <div class="col-offset-fluid clearfix">
        <div class="col-bs10-10">
          <nav class="nav">
            <div class="nav__home">
              <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="Home">
                <span class="icon icon-xsmall icons-home"></span>
              </a>
            </div>
              <?php
              if ( has_nav_menu( 'menu_utama' ) ) : 
                menu_utama();
              endif;
              ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>
<?php endif; ?>

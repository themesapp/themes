<header class="header">
    <div class="header__top">
          <div class="logo">
              <?php 
                if (function_exists('the_custom_logo')) :
                  if(has_custom_logo()) :
                    echo the_custom_logo();
                  endif;
                endif;
                $blogInfo = get_bloginfo('name');
                if (!empty($blogInfo)) : 
                  if (is_front_page() && is_home()) :
                    brand_h1();
                    else :
                    brand_p();
                  endif;
                endif;
                $description = get_bloginfo( 'description', 'display' );
                if ($description || is_customize_preview()) :
                  brand_description($description);
                endif;
              ?>
          </div>
        <div class="menu--left clearfix bar">
            <div class="menu__item">
                <a href="#sidr" class="menu__link icon-bar" on="tap:AMP.setState({nav: !nav, menu: !menu})" [class]="menu ? 'menu__link icon-bar active' : 'menu__link icon-bar'" id="js--menu">
                    <i></i>
                </a>
            </div>
        </div>
    </div>

<div class="header__scroll">
    <div class="header__scroll__slide">
        <div class="header__scroll__wrap">
              <?php
              if ( has_nav_menu( 'mobile_menu' ) ) : 
                mobile_menu();
              endif;
              ?>
        </div>
    </div>
</div>
</header>
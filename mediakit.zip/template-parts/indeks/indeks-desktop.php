<div class="row clearfix">
  <div class="container clearfix">
    <div class="col-offset-fluid clearfix">
      <div class="col-bs12-12">
        <!-- ads top -->
      </div>
      <div class="col-bs10-7">
        <!-- latest -->
        <section class="page clearfix">
          <h3 class="title">
            <span>Index</span>
          </h3>
          <div class="filter clearfix">
            <div class="filter__title col-bs10-3 col-offset-0"><?php the_title(); ?></div>
            <div class="filter__tanggal col-bs10-7 col-offset-0">
              <span>Pilih Tanggal</span>
              <div id="reportrange" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; display:inline-block">
                <span id="daterange"></span>
                <i class="icon icon-caret-down"></i>
              </div>
            </div>
          </div>
          <div class="latest__wrap">
            <?php
            global $post;
            $url = $_GET['daterange'];
            $exp = explode(' - ',$url);
            $timestart = strtotime($exp[0]. ' - 1 days');
            $timeend = strtotime($exp[1]. ' + 1 days');
            $start = date('Y-m-d',$timestart);
            $end = date('Y-m-d',$timeend);
            $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
			if(isset($_GET['daterange'])):
              $args = array(
                'post_type' => 'post',
                'post_status' => 'publish',
				'paged' => $paged,
                'date_query' => array(
                              array(
                                'after'     => $start,
                                'before'    => $end,
                              ),
                          ),
              );
			else:
              $args = array(
                'post_type' => 'post',
				'paged' => $paged,
                'post_status' => 'publish',
              );
			endif;
            $my_query = new WP_Query( $args );
            if ( $my_query->have_posts() ): ?>
              <?php
              while ( $my_query->have_posts() ) {
                $my_query->the_post();
                ?>
                <div class="latest__item">
                  <div class="latest__img">
                    <a href="<?php echo get_permalink(); ?>">
                      <?php echo customthumbnail($post->ID, "image_188_113"); ?>
                    </a>
                  </div>
                  <div class="latest__right">
                    <h4 class="latest__subtitle">
                      <a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a>
                    </h4>
                    <h2 class="latest__title">
                      <a href="<?php echo get_permalink(); ?>" class="latest__link"><?php echo get_the_title(); ?></a>
                    </h2>
                    <date class="latest__date"><?php echo timeago(); ?></date>
                  </div>
                </div>
                <?php
                }
                wp_reset_postdata();
                ?>
            <?php endif; ?>
          </div>
            <?php 
            if($my_query->max_num_pages > 1):
             ?>
              <div class="paging paging--page clearfix">
                <div class="paging__wrap clearfix">
                  <?php
                $big = 999999999; // need an unlikely integer
                 
                echo paginate_links( array(
                    'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                    'format'  => '?paged=%#%',
                    'current' => max( 1, get_query_var('paged') ),
                    'total'   => $my_query->max_num_pages,
                    'next_text' => 'Next',
                    'prev_text' => 'Prev',
                ) );
                ?>
                </div>
              </div>
          <?php endif; ?>
        </section>
      </div>
      <div class="col-bs10-3">
    <?php if (is_active_sidebar("sidebar_area")):
      dynamic_sidebar("sidebar_area");
  endif; ?>
      </div>
    </div>
  </div>
</div>
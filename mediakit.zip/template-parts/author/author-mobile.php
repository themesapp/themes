<div class="row clearfix">
  <div class="container clearfix">
	<?php if (have_posts()): ?>
		<section class="page clearfix">
    		<h3 class="title"><span>Penulis : <?php echo get_the_author(); ?></span></h3>
		  <div class="latest__wrap">
			<?php while (have_posts()): the_post(); ?>
	          <div class="latest__item">
	            <div class="latest__img">
	              <a href="<?php echo get_permalink(); ?>">
	                <?php echo customthumbnail($post->ID, "image_188_113"); ?>
	              </a>
	            </div>
	            <div class="latest__right">
	              <h4 class="latest__subtitle">
	                <a href="<?php echo linkcategory(); ?>"><?php echo labelcategory(); ?></a>
	              </h4>
	              <h2 class="latest__title">
	                <a href="<?php echo get_permalink(); ?>" class="latest__link"><?php echo get_the_title(); ?></a>
	              </h2>
	              <date class="latest__date"><?php echo timeago(); ?></date>
	            </div>
	          </div>
			<?php endwhile; ?>
		  </div>
		  <?php 
			global $wp_query;
			if($wp_query->max_num_pages > 1):
			 ?>
			  <div class="paging paging--page clearfix">
			    <div class="paging__wrap clearfix">
			    	<?php
					$big = 999999999; // need an unlikely integer
					 
					echo paginate_links( array(
					    'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
					    'format'  => '?paged=%#%',
					    'current' => max( 1, get_query_var('paged') ),
					    'total'   => $wp_query->max_num_pages,
					    'next_text' => 'Next',
					    'prev_text' => 'Prev',
					) );
					?>
			    </div>
			  </div>
		<?php endif; ?>
		</section>
	<?php endif; ?>
		<?php 
		if (is_active_sidebar('sidebar_area')) :
			dynamic_sidebar('sidebar_area');
		endif;
		?>
  </div>
</div>
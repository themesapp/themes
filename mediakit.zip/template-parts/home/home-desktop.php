<div class="row clearfix">
  <div class="container clearfix">
    <div class="col-offset-fluid clearfix">
      <div class="col-bs10-7">
		<?php 
		if (is_active_sidebar('tophomepage_area')) :
			dynamic_sidebar('tophomepage_area');
		endif;
		?>
      </div>
      <div class="col-bs10-3">
		<?php 
		if (is_active_sidebar('sidebar_area')) :
			dynamic_sidebar('sidebar_area');
		endif;
		?>
      </div>
    </div>
  </div>
</div>
<div class="row clearfix">
    <div class="container clearfix">  
        <?php 
        if (is_active_sidebar('tophomepage_area')) :
            dynamic_sidebar('tophomepage_area');
        endif;
        ?>
        <?php 
        if (is_active_sidebar('sidebar_area')) :
            dynamic_sidebar('sidebar_area');
        endif;
        ?>
    </div>
</div>
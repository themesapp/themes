<?php 
add_shortcode( 'related', 'related_shortcode' );
function related_shortcode( $atts ) {
	global $post;
	$by = $atts["by"];
	$num = $atts["number"];
	if($by == "category"){
	    $categories = get_the_category( $post->ID );
	    $categorieIDs = array();
		if ( $categories ) {
			$categoriecount = count( $categories );
	        for ( $i = 0; $i < $categoriecount; $i++ ) {
	            $categorieIDs[$i] = $categories[$i]->term_id;
	        }
	        $argsrelated = array(
	            'category__in' => $categorieIDs,
				'post_type' => 'post',
				'post_status' => 'publish',
	            'post__not_in' => array( $post->ID ),
   	  			'offset' => $num,
	            'posts_per_page'=> 1
	        );
	    }
	} else if($by == "tag"){
	    $tags = wp_get_post_tags( $post->ID );
	    $tagIDs = array();

		if ( $tags ) {
			$tagcount = count( $tags );
	        for ( $i = 0; $i < $tagcount; $i++ ) {
	            $tagIDs[$i] = $tags[$i]->term_id;
	        }
	        $argsrelated = array(
	            'tag__in' => $tagIDs,
				'post_type' => 'post',
				'post_status' => 'publish',
	            'post__not_in' => array( $post->ID ),
   	  			'offset' => $num,
	            'posts_per_page'=> 1
	        );
	    }
	}else{
	    $argsrelated = array(
			'post_type' => 'post',
			'post_status' => 'publish',
	        'post__not_in' => array( $post->ID ),
   	  		'offset' => $num,
	        'posts_per_page'=> 1
	    );

	}

	$konten = "";
	$my_related = new WP_Query( $argsrelated );
	if ( $my_related->have_posts() ):
		while ( $my_related->have_posts() ) {
			$my_related->the_post();
			$konten .= '<p>';
			$konten .= '<strong>Baca Juga: <a href="' . get_permalink(). '">'. get_the_title() .'</a></strong>';
			$konten .= '</p>';
		}
	endif;
	wp_reset_postdata();
	return $konten;
}
?>
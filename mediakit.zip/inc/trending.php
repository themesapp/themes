<?php 
add_shortcode( 'trending', 'trending_shortcode' );
function trending_shortcode( $atts ) {
	global $post;
	$rentang = $atts["rentang"];
	$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
		$argstrending = array(
			'post_type' => 'post',
			'meta_key' => 'post_views_count',
			'orderby'   => 'meta_value_num',
			'post_status' => 'publish',
            'paged' => $paged,
			'order' => 'DESC',
			'date_query' => array(
				array(
					'after' => $rentang,
				),
			)
		);
	$konten = "";
	$my_trending = new WP_Query( $argstrending );
	if ( $my_trending->have_posts() ):
		$konten .= '<div class="latest__wrap">';
		while ( $my_trending->have_posts() ) {
			$my_trending->the_post();
			$konten .= '
                <div class="latest__item">
                  <div class="latest__img">
                    <a href="' . get_permalink(). '">
                    ' . customthumbnail($post->ID, "image_188_113"). '
                    </a>
                  </div>
                  <div class="latest__right">
                    <h4 class="latest__subtitle">
                      <a href="' . linkcategory(). '">'. labelcategory() .'</a>
                    </h4>
                    <h2 class="latest__title">
                      <a href="' . get_permalink(). '" class="latest__link">' . get_the_title() . '</a>
                    </h2>
                    <date class="latest__date">' . timeago() . '</date>
                  </div>
                </div>';
		}
		$konten .= '</div>';
        if($my_trending->max_num_pages > 1):
        	$konten .= '<div class="paging paging--page clearfix">
            <div class="paging__wrap clearfix">';
            $big = 999999999; // need an unlikely integer
             
            $konten .= paginate_links( array(
                'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                'format'  => '?paged=%#%',
                'current' => max( 1, get_query_var('paged') ),
                'total'   => $my_trending->max_num_pages,
                'next_text' => 'Next',
                'prev_text' => 'Prev',
            ) );

            $konten .= '</div>
          </div>';
      endif;
	endif;
	wp_reset_postdata();
	return '<div class="list-wrap">' . $konten . '</div>';
}
?>
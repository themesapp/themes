<?php 
function billboard_area() {
    $args = array(
      'name'          => 'Iklan Header', 
      'id'            => 'billboard_area',
      'description'   => 'Menampilkan ADS Billboard ukuran 970x250px atau iklan responsif',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'billboard_area' );


function tophomepage_area() {
    $args = array(
      'name'          => 'Beranda', 
      'id'            => 'tophomepage_area',
      'description'   => 'Menampilkan widget dibagian atas',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="title"><span>',
      'after_title'   => '</span></h3>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'tophomepage_area' );

function afterpos_area() {
    $args = array(
      'name'          => 'Setelah Pos', 
      'id'            => 'afterpos_area',
      'description'   => 'Menampilkan widget di bagian bawah setelah artikel',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'afterpos_area' );

function sidebar_area() {
    $args = array(
      'name'          => 'Sidebar', 
      'id'            => 'sidebar_area',
      'description'   => 'Menampilkan widget di dibagian sidebar.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sidebar_area' );


function footer_brand() {
    $args = array(
      'name'          => 'Footer Logo', 
      'id'            => 'footer_brand',
      'description'   => 'Menampilkan data brand dibagian footer kiri.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_brand' );

function footer_contact() {
    $args = array(
      'name'          => 'Footer Contact', 
      'id'            => 'footer_contact',
      'description'   => 'Menampilkan data kontak dibagian footer kiri.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_contact' );

function footer_nav() {
    $args = array(
      'name'          => 'Footer Menu', 
      'id'            => 'footer_nav',
      'description'   => 'Menampilkan data menu dibagian footer tengah.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="title"><span>',
      'after_title'   => '</span></h3>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_nav' );

function footer_alternatif() {
    $args = array(
      'name'          => 'Footer Alternatif', 
      'id'            => 'footer_alternatif',
      'description'   => 'Menampilkan data menu alternatif dibagian footer kanan.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="title"><span>',
      'after_title'   => '</span></h3>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_alternatif' );


function footer_email() {
    $args = array(
      'name'          => 'Footer Media Network', 
      'id'            => 'footer_email',
      'description'   => 'Menampilkan data menu ikutin dibagian footer kanan.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="title"><span>',
      'after_title'   => '</span></h3>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_email' );

function footer_left() {
    $args = array(
      'name'          => 'About Us', 
      'id'            => 'footer_left',
      'description'   => 'Menampilkan data menu ikutin dibagian footer kanan.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_left' );

function footer_right() {
    $args = array(
      'name'          => 'Copyright', 
      'id'            => 'footer_right',
      'description'   => 'Menampilkan data menu ikutin dibagian footer kanan.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'footer_right' );

function sticky_ads_left() {
    $args = array(
      'name'          => 'Iklan Sticky Kiri', 
      'id'            => 'sticky_ads_left',
      'description'   => 'Menampilkan widget ads secara sticky dibagian kiri.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_left' );

function sticky_ads_right() {
    $args = array(
      'name'          => 'Iklan Sticky Kanan', 
      'id'            => 'sticky_ads_right',
      'description'   => 'Menampilkan widget ads secara sticky dibagian kiri.',
      'before_widget' => '<div class="widget">',
      'after_widget'  => '</div>',
      'before_title'  => '<div class="widget-header"><h2 class="widget-title">',
      'after_title'   => '</h2></div>',

    );
register_sidebar( $args );
}
add_action( 'widgets_init', 'sticky_ads_right' );

?>
<?php 
function addcss() { 
    $versi = '3.1.0.0';
    wp_enqueue_style( 'font', get_template_directory_uri() . '/assets/css/font.css', '', $versi );

    if(!empty(get_theme_mod( 'font' ))):
      if(get_theme_mod( 'font' ) == "Roboto, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Montserrat, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Lato, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "'PT Sans', sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Poppins, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "'Source Sans Pro', sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "'Roboto Mono', sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "'Noto Sans', sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Inter, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Ubuntu, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Mukta, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Mukta:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Merriweather, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Rubik, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Lora, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Lora:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Quicksand, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "'PT Serif', sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=PT+Serif:wght@400;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Heebo, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "'Noto Serif', sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Noto+Serif:wght@400;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "'DM Sans', sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Manrope, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Questrial, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Questrial&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Chivo, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Baskervville, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Baskervville&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Mulish, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Mulish:wght@400;500;600;700&display=swap', '', $versi );
      elseif(get_theme_mod( 'font' ) == "Inter, sans-serif"):
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', '', $versi );
      endif;
    else:
      wp_enqueue_style( 'fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', '', $versi );
    endif;

    wp_enqueue_style( 'normalize', get_template_directory_uri() . '/assets/css/normalize.css', '', $versi );
  if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
    wp_enqueue_style( 'amp', get_template_directory_uri() . '/assets/css/style-amp.css', '', $versi );
	}elseif(wp_is_mobile()) {
    wp_enqueue_style( 'mobile', get_template_directory_uri() . '/assets/css/style-mobile.css', '', $versi );
  }else {
    wp_enqueue_style( 'desktop', get_template_directory_uri() . '/assets/css/style-desktop.css', '', $versi );
  }
}
add_action( 'wp_enqueue_scripts', 'addcss' );

function addattrcss( $html, $handle ) {
    if ('cssmobile' === $handle 
        || 'normalize' === $handle 
        || 'dashicons' === $handle 
        || 'admin-bar' === $handle 
        || 'wp-block-library' === $handle 
        || 'font' === $handle 
        || 'fonts' === $handle 
        || 'amp' === $handle 
        || 'mobile' === $handle 
        || 'desktop' === $handle 
    ) :
        return str_replace( "media='all'", "media='all' async='async'", $html );
    endif;
    return $html;
}
add_filter( 'style_loader_tag', 'addattrcss', 10, 2 );

function customcss()
{
?>
<style type="text/css" id="custom-theme-css">
:root {
<?php if(!empty(get_theme_mod( 'gradient1' ))):?>
  --gradient1: <?php echo get_theme_mod( 'gradient1' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'gradient2' ))):?>
  --gradient2: <?php echo get_theme_mod( 'gradient2' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'footergradient1' ))):?>
  --footergradient1: <?php echo get_theme_mod( 'footergradient1' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'footergradient2' ))):?>
  --footergradient2: <?php echo get_theme_mod( 'footergradient2' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'title' ))):?>
  --title: <?php echo get_theme_mod( 'title' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'garis' ))):?>
  --garis: <?php echo get_theme_mod( 'garis' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'titlepost' ))):?>
  --titlepost: <?php echo get_theme_mod( 'titlepost' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'utama' ))):?>
  --utama: <?php echo get_theme_mod( 'utama' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'font' ))):?>
  --font: <?php echo get_theme_mod( 'font' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'bgmenu' ))):?>
  --bgmenu: <?php echo get_theme_mod( 'bgmenu' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'txtmenu' ))):?>
  --menucolor: <?php echo get_theme_mod( 'txtmenu' ); ?>;
<?php endif; ?>
<?php if(!empty(get_theme_mod( 'txthvrmenu' ))):?>
  --menuhover: <?php echo get_theme_mod( 'txthvrmenu' ); ?>;
<?php endif; ?>
	
<?php if(!empty(get_theme_mod( 'txtfooter' ))):?>
  --colorfooter: <?php echo get_theme_mod( 'txtfooter' ); ?>;
<?php endif; ?>
}
</style>
<?php
}
add_action( 'wp_head', 'customcss');
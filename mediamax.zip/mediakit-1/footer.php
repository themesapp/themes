<?php wp_footer(); ?>
<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
  if ( "" != (get_theme_mod( 'insertfooteramp' ))) :
  	 echo get_theme_mod( 'insertfooteramp' );
  endif;
}else{
  if ( "" != (get_theme_mod( 'insertfooter' ))) :
  	 echo get_theme_mod( 'insertfooter' );
  endif;
}
?>
</body>
</html>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<?php wp_head(); ?>
<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
  if ( "" != (get_theme_mod( 'insertheaderamp' ))) :
  	 echo get_theme_mod( 'insertheaderamp' );
  endif;
}else{
  if ( "" != (get_theme_mod( 'insertheader' ))) :
  	 echo get_theme_mod( 'insertheader' );
  endif;
}
?>
<link rel="profile" href="http://gmpg.org/xfn/11" />
</head>
<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
?>
<body [class]="darkmode ? '<?php echo esc_attr( implode( ' ', get_body_class() ) ); ?> darkmode' : '<?php echo esc_attr( implode( ' ', get_body_class() ) ); ?>'" <?php body_class(); ?> >
<?php
}else{
?>
<body <?php body_class(); ?> >
<?php
}
?>
<?php wp_body_open(); ?>
jQuery( document ).ready(function() {
var x = localStorage.getItem("toggled");
jQuery(".mode").click(function() {
    "dark-mode" != localStorage.toggled ? (
        jQuery("body").toggleClass("darkmode", !0), 
        localStorage.toggled = "dark-mode"
    ) : (
        jQuery("body").toggleClass("darkmode", !1), 
        localStorage.toggled = ""
    )
    
    var y = localStorage.getItem("toggled");
    if ( y == "dark-mode") {
        jQuery(".mode i").removeClass("dark");
        jQuery(".mode i").addClass("light");
    }else{
        jQuery(".mode i").removeClass("light");  
        jQuery(".mode i").addClass("dark");
    }
});

if ( x == "dark-mode") {
    jQuery(".mode i").removeClass("dark"),
    jQuery(".mode i").addClass("light"),
    jQuery("body").addClass("darkmode");
}else{
    jQuery(".mode i").removeClass("light"),  
    jQuery(".mode i").addClass("dark"),
    jQuery("body").removeClass("darkmode"); 
}
});
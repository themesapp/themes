<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
}elseif (wp_is_mobile()) {
}else{
?>
<div class="sticky-box">
  <?php if (is_active_sidebar('sticky_ads_left')) :?>
    <div class="ads-sticky sticky-left">
      <div class="ads-sticky-box">
        <?php dynamic_sidebar('sticky_ads_left'); ?>
      </div>
    </div>
    <?php endif; ?>
  <?php if (is_active_sidebar('sticky_ads_right')) :?>
    <div class="ads-sticky sticky-right">
      <div class="ads-sticky-box">
        <?php dynamic_sidebar('sticky_ads_right'); ?>
      </div>
    </div>
    <?php endif; ?>
</div>
<?php } ?>
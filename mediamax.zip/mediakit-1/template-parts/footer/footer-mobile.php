<footer class="footer">
  <div class="footer-logo-box">
    <div class="container">
        <?php
        if ( is_active_sidebar( 'footer_brand' ) ) : ?>
        <div class="footer-logo">
        <?php dynamic_sidebar('footer_brand'); ?>
        </div>
        <?php endif;
        ?>
      
    </div>
  </div>
  <div class="footer-center-box">
  <div class="container">
    <div class="row">
      <div class="col-12 footer-contact">
        <?php
        if ( is_active_sidebar( 'footer_contact' ) ) : ?>
        <?php dynamic_sidebar('footer_contact'); ?>
        <?php endif;
        ?>
      </div>
      <div class="col-12">
        <?php
        if ( is_active_sidebar( 'footer_nav' ) ) : ?>
        <div class="footer-menu">
        <?php dynamic_sidebar('footer_nav'); ?>
        </div>
        <?php endif;
        ?>
      </div>
      <div class="col-12 footer-app-item">
            <div class="social-app-box">
            <?php if ( "" != (get_theme_mod( 'tombolfollowfacebook' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowfacebook' ); ?>" target="_blank" class="social-app-link facebook">
                  <span class="icon icon-facebook"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowtwitter' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowtwitter' ); ?>" target="_blank" class="social-app-link twitter">
                  <span class="icon icon-twitter"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowinstagram' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowinstagram' ); ?>" target="_blank" class="social-app-link instagram">
                  <span class="icon icon-instagram"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowyoutube' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowyoutube' ); ?>" target="_blank" class="social-app-link youtube">
                  <span class="icon icon-youtube"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowtelegram' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowtelegram' ); ?>" target="_blank" class="social-app-link telegram">
                  <span class="icon-telegram"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowdiscord' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowdiscord' ); ?>" target="_blank" class="social-app-link discord">
                  <span class="icon-discord"></span>
                </a>
              </div>
            <?php endif; ?>
            <?php if ( "" != (get_theme_mod( 'tombolfollowgnews' ))) : ?>
              <div class="social-app-item">
                <a href="<?php echo get_theme_mod( 'tombolfollowgnews' ); ?>" target="_blank" class="social-app-link gnews">
                  <span class="icon-gnews"></span>
                </a>
              </div>
            <?php endif; ?>
            </div>
      </div>
    </div>
  </div>
  </div>
  <div class="footer-copyright-box">
    <div class="container">
        <?php 
        if (is_active_sidebar('footer_copyright')) :?>
        <div class="footer-copyright">
        <?php dynamic_sidebar('footer_copyright'); ?>
        </div>
        <?php endif; ?>
    </div>
  </div>
</footer>
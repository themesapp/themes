<?php 
require 'inc/index.php';
require 'widget/index.php';
require 'tgm/example.php';
require 'update/theme-update-checker.php';

$example_update_checker = new ThemeUpdateChecker(
    'mediakit-1',
    'https://update.mediakitnetwork.com/theme/mediamax/update.json'
);
function labelcategory(){
    $category = get_the_category();
    $useCatLink = true;
    // If post has a category assigned.
    if ($category){
        $category_display = '';
        $category_link = '';
        if ( class_exists('WPSEO_Primary_Term') ){
        // Show the post's 'Primary' category, if this Yoast feature is available, & one is set
        $wpseo_primary_term = new WPSEO_Primary_Term( 'category', get_the_id() );
        $wpseo_primary_term = $wpseo_primary_term->get_primary_term();
        $term = get_term( $wpseo_primary_term );
        if (is_wp_error($term)) { 
            // Default to first category (not Yoast) if an error is returned
            $category_display = $category[0]->name;
            $category_link = get_category_link( $category[0]->term_id );
        } else { 
            // Yoast Primary category
            $category_display = $term->name;
            $category_link = get_category_link( $term->term_id );
        }
    } 
    else {
        // Default, display the first category in WP's list of assigned categories
        $category_display = $category[0]->name;
        $category_link = get_category_link( $category[0]->term_id );
    }
    // Display category
    if ( !empty($category_display) ){
        if ( $useCatLink == true && !empty($category_link) ){
            $code = htmlspecialchars($category_display);
        } else {
            $code = htmlspecialchars($category_display);
        }
    	return $code;
    }
    
    }
}

function linkcategory(){
    $category = get_the_category();
    $useCatLink = true;
    // If post has a category assigned.
    if ($category){
        $category_display = '';
        $category_link = '';
        if ( class_exists('WPSEO_Primary_Term') ){
        // Show the post's 'Primary' category, if this Yoast feature is available, & one is set
        $wpseo_primary_term = new WPSEO_Primary_Term( 'category', get_the_id() );
        $wpseo_primary_term = $wpseo_primary_term->get_primary_term();
        $term = get_term( $wpseo_primary_term );
        if (is_wp_error($term)) { 
            // Default to first category (not Yoast) if an error is returned
            $category_display = $category[0]->name;
            $category_link = get_category_link( $category[0]->term_id );
        } else { 
            // Yoast Primary category
            $category_display = $term->name;
            $category_link = get_category_link( $term->term_id );
        }
    } 
    else {
        // Default, display the first category in WP's list of assigned categories
        $category_display = $category[0]->name;
        $category_link = get_category_link( $category[0]->term_id );
    }
    // Display category
    if ( !empty($category_display) ){
        if ( $useCatLink == true && !empty($category_link) ){
            $code = $category_link;
        } else {
            $code = $category_link;
        }
    	return $code;
    }

    }
}
function custom_menu() { 

  add_menu_page( 
      'Dokumentasi', 
      'Dokumentasi', 
      'edit_posts', 
      'dokumentasi', 
      'my_admin_page_contents', 
      'dashicons-format-aside' ,
      30
     );
}
function my_admin_page_contents() {
?>
        <h1>Informasi</h1>

       <p>Hi Guys,</p>
<p>Kita ada ruang diskusi di Facebook untuk seluruh pengguna tema WordPress MediaMax.</p>
<p>Di grup ini Kamu bisa diskusi, tanya atau saling berbagi informasi terkait tema WordPress.</p>
<p>Join 👉🏻 <a href="https://bit.ly/FBMEDIAKITNETWORK">https://bit.ly/FBMEDIAKITNETWORK</a></p>
<p>Pastikan tulis domain Kamu yang menggunakan tema MediaMax ya.</p>
<p>Terima kasih.</p>
<br>
        <p><strong>1. Informasi Tema</strong></p>
        <p>📌 <a href="https://coda.io/d/_dUfuORMc-Hv/Informasi_sukTU">Kenali MediaMax Lebih Dekat</a></p>
        <p><strong>2. Dokumentasi Tema</strong></p>
        <p>📌 <a href="https://coda.io/d/_dUfuORMc-Hv/Dokumentasi_su0j_">Cara Setting Tema MediaMax</a></p>
		<p><strong>3. Request Lisensi</strong></p>
		<p>📌 <a href="#">Lisensi MediaMax</a></p>
    <?php
}
add_action('admin_menu', 'custom_menu');

function ocdi_register_plugins( $plugins ) {
  $theme_plugins = [
    [ // A WordPress.org plugin repository example.
      'name'     => 'Ad Inserter – Ad Manager & AdSense Ads', // Name of the plugin.
      'slug'     => 'ad-inserter', // Plugin slug - the same as on WordPress.org plugin repository.
      'required' => true,                     // If the plugin is required or not.
    ],
    [ // A locally theme bundled plugin example.
      'name'     => 'AMP',
      'slug'     => 'amp',         // The slug has to match the extracted folder from the zip.
      'required' => true,                     // If the plugin is required or not.
    ],
    [
      'name'        => 'One Click Demo Import',
      'slug'        => 'one-click-demo-import',  // The slug has to match the extracted folder from the zip.
      'required' => true,                     // If the plugin is required or not.
    ],
  ];
 
  return array_merge( $plugins, $theme_plugins );
}
add_filter( 'ocdi/register_plugins', 'ocdi_register_plugins' );
?>
<?php
function contactViewDesktop($judul, $alamat, $email_1, $email_2, $phone_1, $phone_2){
	if(!empty($alamat)):
		echo '<div class="contact-item"><i class="icon icons-home"></i> ' . $alamat . '</div>';
	endif;
	if(!empty($email_1)):
		echo '<div class="contact-item"><i class="icon icons-mail"></i> ' . $email_1 . '</div>';
	endif;
	if(!empty($email_2)):
		echo '<div class="contact-item"><i class="icon icons-mail"></i> ' . $email_2 . '</div>';
	endif;
	if(!empty($phone_1)):
		echo '<div class="contact-item"><i class="icon icons-call"></i> ' . $phone_1 . '</div>';
	endif;
	if(!empty($phone_2)):
		echo '<div class="contact-item"><i class="icon icons-call"></i> ' . $phone_2 . '</div>';
	endif;
}
function contactViewMobile($judul, $alamat, $email_1, $email_2, $phone_1, $phone_2){
	if(!empty($alamat)):
		echo '<div class="contact-item"><i class="icon icons-home"></i> ' . $alamat . '</div>';
	endif;
	if(!empty($email_1)):
		echo '<div class="contact-item"><i class="icon icons-mail"></i> ' . $email_1 . '</div>';
	endif;
	if(!empty($email_2)):
		echo '<div class="contact-item"><i class="icon icons-mail"></i> ' . $email_2 . '</div>';
	endif;
	if(!empty($phone_1)):
		echo '<div class="contact-item"><i class="icon icons-call"></i> ' . $phone_1 . '</div>';
	endif;
	if(!empty($phone_2)):
		echo '<div class="contact-item"><i class="icon icons-call"></i> ' . $phone_2 . '</div>';
	endif;
}
class contactWidget extends WP_Widget {

	public function __construct() {
		$idwidget = 'contact';
		$namewidget = '📌 Kontak';
		$descwidget = 'Widget ini menampilan daftar contact';
		parent::__construct($idwidget, $namewidget, array('description'=> $descwidget));
	}
	public function widget( $args, $instance ) {
		if($instance['mobile'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
				contactViewMobile($instance['title'], $instance['alamat'], $instance['email_1'], $instance['email_2'], $instance['phone_1'], $instance['phone_2']);
			}elseif (wp_is_mobile()) {
				contactViewMobile($instance['title'], $instance['alamat'], $instance['email_1'], $instance['email_2'], $instance['phone_1'], $instance['phone_2']);
			}
		}
		if($instance['desktop'] == 'yes'){
			if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
			}elseif (wp_is_mobile()) {
			}else{
				contactViewDesktop($instance['title'], $instance['alamat'], $instance['email_1'], $instance['email_2'], $instance['phone_1'], $instance['phone_2']);
			}
		}
	}
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		if ( ! empty( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
		}
		if ( ! empty( $new_instance['alamat'] ) ) {
			$instance['alamat'] = sanitize_text_field( $new_instance['alamat'] );
		}
		if ( ! empty( $new_instance['email_1'] ) ) {
			$instance['email_1'] = sanitize_text_field( $new_instance['email_1'] );
		}
		if ( ! empty( $new_instance['email_2'] ) ) {
			$instance['email_2'] = sanitize_text_field( $new_instance['email_2'] );
		}
		if ( ! empty( $new_instance['phone_1'] ) ) {
			$instance['phone_1'] = sanitize_text_field( $new_instance['phone_1'] );
		}
		if ( ! empty( $new_instance['phone_2'] ) ) {
			$instance['phone_2'] = sanitize_text_field( $new_instance['phone_2'] );
		}
		$instance['desktop'] = isset( $new_instance['desktop'] ) ? 'yes' : 'no';
		$instance['mobile'] = isset( $new_instance['mobile'] ) ? 'yes' : 'no';
		return $instance;
	}
	public function form( $instance ) {
		$defaults = array(
			'title' => '',
			'alamat' => '',
			'email_1' => '',
			'email_2' => '',
			'phone_1' => '',
			'phone_2' => '',
			'desktop' => 'yes',
			'mobile' => 'yes',
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		?>
		<div class="related-form-controls">
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan contact</h3>

			<p>
				<label for="<?php echo $this->get_field_id( 'alamat' ); ?>"><?php _e( 'Alamat:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'alamat' ); ?>" name="<?php echo $this->get_field_name( 'alamat' ); ?>" value="<?php echo $instance['alamat']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'email_1' ); ?>"><?php _e( 'Email:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'email_1' ); ?>" name="<?php echo $this->get_field_name( 'email_1' ); ?>" value="<?php echo $instance['email_1']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'email_2' ); ?>"><?php _e( 'Email Opsional:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'email_2' ); ?>" name="<?php echo $this->get_field_name( 'email_2' ); ?>" value="<?php echo $instance['email_2']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'phone_1' ); ?>"><?php _e( 'No Telepon:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'phone_1' ); ?>" name="<?php echo $this->get_field_name( 'phone_1' ); ?>" value="<?php echo $instance['phone_1']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'phone_2' ); ?>"><?php _e( 'No Telepon Opsional:' ); ?></label>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'phone_2' ); ?>" name="<?php echo $this->get_field_name( 'phone_2' ); ?>" value="<?php echo $instance['phone_2']; ?>" />
			</p>
			<hr>
			<h3>Pengaturan Tampilan</h3>
			<p>
				<input type="checkbox" id="<?php echo $this->get_field_id( 'desktop' ); ?>" name="<?php echo $this->get_field_name( 'desktop' ); ?>" value="yes"<?php checked( 'yes', $instance['desktop'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'desktop' ); ?>">Tampilkan dalam versi desktop</label><br>

				<input type="checkbox" id="<?php echo $this->get_field_id( 'mobile' ); ?>" name="<?php echo $this->get_field_name( 'mobile' ); ?>" value="yes"<?php checked( 'yes', $instance['mobile'] ); ?>>
				<label for="<?php echo $this->get_field_id( 'mobile' ); ?>">Tampilkan dalam versi mobile</label>
			</p>
		</div>
		<?php
	}
}

function contactWidgetload() {
	register_widget( 'contactWidget' );
}
add_action( 'widgets_init', 'contactWidgetload' );
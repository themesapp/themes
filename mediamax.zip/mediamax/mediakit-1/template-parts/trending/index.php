<?php 
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) {
    require "trending-amp.php";
}elseif (wp_is_mobile()) {
    require "trending-mobile.php";
}else{
    require "trending-desktop.php";
}
?>
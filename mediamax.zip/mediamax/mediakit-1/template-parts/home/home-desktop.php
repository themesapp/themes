<main class="main">
	<div class="container">
		<div class="row">
			<div class="col-8">
			<?php 
			if (is_active_sidebar('tophomepage_area')) :
				dynamic_sidebar('tophomepage_area');
			endif;
			?>
			</div>
			<aside class="col-4">
			<?php 
			if (is_active_sidebar('sidebar_area')) :
				dynamic_sidebar('sidebar_area');
			endif;
			?>
			</aside>
		</div>
	</div>
</main>